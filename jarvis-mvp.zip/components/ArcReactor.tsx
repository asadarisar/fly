"use client"

import { useEffect, useState } from "react"

interface ArcReactorProps {
  isActive?: boolean
  isListening?: boolean
  isSpeaking?: boolean
}

export function ArcReactor({ isActive = false, isListening = false, isSpeaking = false }: ArcReactorProps) {
  const [pulseIntensity, setPulseIntensity] = useState(0.5)

  useEffect(() => {
    if (isSpeaking) {
      setPulseIntensity(0.9)
    } else if (isListening) {
      setPulseIntensity(0.7)
    } else if (isActive) {
      setPulseIntensity(0.5)
    } else {
      setPulseIntensity(0.3)
    }
  }, [isActive, isListening, isSpeaking])

  return (
    <div className="relative w-32 h-32 mx-auto mb-6">
      {/* Outer Ring */}
      <div
        className={`absolute inset-0 rounded-full border-4 transition-all duration-300 ${
          isActive ? "border-cyan-400 shadow-lg shadow-cyan-400/50" : "border-gray-600"
        }`}
        style={{
          boxShadow: isActive
            ? `0 0 20px rgba(6, 182, 212, ${pulseIntensity}), 0 0 40px rgba(6, 182, 212, ${pulseIntensity * 0.5})`
            : "none",
        }}
      >
        {/* Inner Circles */}
        <div className="absolute inset-4 rounded-full border-2 border-cyan-300/60">
          <div className="absolute inset-2 rounded-full border border-cyan-200/40">
            {/* Core */}
            <div
              className={`absolute inset-2 rounded-full transition-all duration-300 ${
                isActive ? "bg-cyan-400" : "bg-gray-500"
              }`}
              style={{
                boxShadow: isActive
                  ? `inset 0 0 20px rgba(6, 182, 212, ${pulseIntensity}), 0 0 30px rgba(6, 182, 212, ${pulseIntensity})`
                  : "none",
              }}
            >
              {/* Animated Rings */}
              {isActive && (
                <>
                  <div
                    className="absolute inset-0 rounded-full border border-white/30 animate-spin"
                    style={{ animationDuration: "3s" }}
                  ></div>
                  <div
                    className="absolute inset-1 rounded-full border border-white/20 animate-spin"
                    style={{ animationDuration: "2s", animationDirection: "reverse" }}
                  ></div>
                  <div
                    className="absolute inset-2 rounded-full border border-white/10 animate-spin"
                    style={{ animationDuration: "4s" }}
                  ></div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Pulse Rings */}
        {(isListening || isSpeaking) && (
          <>
            <div
              className={`absolute inset-0 rounded-full border-2 animate-ping ${
                isListening ? "border-red-400" : "border-green-400"
              }`}
              style={{ animationDuration: "1s" }}
            ></div>
            <div
              className={`absolute inset-2 rounded-full border animate-ping ${
                isListening ? "border-red-300" : "border-green-300"
              }`}
              style={{ animationDuration: "1.5s", animationDelay: "0.2s" }}
            ></div>
          </>
        )}
      </div>

      {/* Status Text */}
      <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 text-xs text-center">
        <span
          className={`${
            isSpeaking ? "text-green-400" : isListening ? "text-red-400" : isActive ? "text-cyan-400" : "text-gray-500"
          }`}
        >
          {isSpeaking ? "SPEAKING" : isListening ? "LISTENING" : isActive ? "ONLINE" : "STANDBY"}
        </span>
      </div>
    </div>
  )
}
