"use client"

import { useEffect, useState } from "react"

interface ProHUDProps {
  isActive?: boolean
  isListening?: boolean
  isSpeaking?: boolean
}

export function ProHUD({ isActive = false, isListening = false, isSpeaking = false }: ProHUDProps) {
  const [radarAngle, setRadarAngle] = useState(0)
  const [pulseIntensity, setPulseIntensity] = useState(0.3)
  const [dataStreams, setDataStreams] = useState<Array<{ id: number; x: number; y: number; speed: number }>>([])

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        setRadarAngle((prev) => (prev + 1.5) % 360)
      }, 30)
      return () => clearInterval(interval)
    }
  }, [isActive])

  useEffect(() => {
    if (isSpeaking) {
      setPulseIntensity(0.95)
    } else if (isListening) {
      setPulseIntensity(0.8)
    } else if (isActive) {
      setPulseIntensity(0.6)
    } else {
      setPulseIntensity(0.3)
    }
  }, [isActive, isListening, isSpeaking])

  // Generate data streams
  useEffect(() => {
    if (isActive) {
      const streams = Array.from({ length: 15 }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        speed: 0.5 + Math.random() * 1.5,
      }))
      setDataStreams(streams)
    }
  }, [isActive])

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Advanced Corner HUD Elements */}
      <div className="absolute top-0 left-0 w-80 h-80">
        <div className="relative w-full h-full">
          {/* Animated Corner Frame */}
          <div className="absolute top-4 left-4 w-64 h-64">
            <div className="w-full h-full border-l-4 border-t-4 border-cyan-400/40 rounded-tl-2xl relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/10 to-transparent"></div>
              
              {/* Scanning Lines */}
              <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-cyan-400 to-transparent animate-pulse"></div>
              <div className="absolute top-0 left-0 w-0.5 h-full bg-gradient-to-b from-cyan-400 to-transparent animate-pulse"></div>
              
              {/* Data Display */}
              <div className="absolute top-4 left-4 text-xs text-cyan-400/80 font-mono space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span>STATUS: {isActive ? "ONLINE" : "STANDBY"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${isSpeaking ? 'bg-green-400 animate-ping' : isListening ? 'bg-red-400 animate-pulse' : 'bg-yellow-400'}`}></div>
                  <span>MODE: {isSpeaking ? "OUTPUT" : isListening ? "INPUT" : "READY"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                  <span>CORE: {Math.floor(pulseIntensity * 100)}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                  <span>NET: SECURE</span>
                </div>
              </div>

              {/* Mini Radar */}
              <div className="absolute bottom-4 left-4 w-16 h-16">
                <div className="relative w-full h-full border border-cyan-400/30 rounded-full">
                  {[1, 2, 3].map((ring) => (
                    <div
                      key={ring}
                      className="absolute border border-cyan-400/20 rounded-full"
                      style={{
                        width: `${ring * 33}%`,
                        height: `${ring * 33}%`,
                        top: `calc(50% - ${ring * 16.5}px)`,
                        left: `calc(50% - ${ring * 16.5}px)`,
                      }}
                    />
                  ))}
                  {isActive && (
                    <div
                      className="absolute w-8 h-0.5 bg-gradient-to-r from-cyan-400 to-transparent origin-left top-1/2 left-1/2"
                      style={{
                        transform: `rotate(${radarAngle}deg)`,
                      }}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Right Advanced Display */}
      <div className="absolute top-0 right-0 w-80 h-80">
        <div className="absolute top-4 right-4 w-64 h-64">
          <div className="w-full h-full border-r-4 border-t-4 border-cyan-400/40 rounded-tr-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-bl from-cyan-400/10 to-transparent"></div>
            
            {/* System Info */}
            <div className="absolute top-4 right-4 text-xs text-cyan-400/80 font-mono text-right space-y-1">
              <div className="text-lg font-bold text-cyan-300">FLY AI v3.0</div>
              <div className="text-cyan-400/60">ASAD ARISAR</div>
              <div className="mt-2 space-y-1">
                <div>⚡ QUANTUM CORE</div>
                <div>🛡️ NEURAL SHIELD</div>
                <div>🌐 GLOBAL NET</div>
                <div>🎯 PRECISION AI</div>
              </div>
              <div className="mt-3 text-xs">
                <div>{new Date().toLocaleTimeString()}</div>
                <div>{new Date().toLocaleDateString()}</div>
              </div>
            </div>

            {/* Performance Bars */}
            <div className="absolute bottom-4 right-4 space-y-2">
              {['CPU', 'MEM', 'NET', 'AI'].map((label, index) => (
                <div key={label} className="flex items-center gap-2 text-xs text-cyan-400">
                  <span className="w-6">{label}</span>
                  <div className="w-20 h-1 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full transition-all duration-1000"
                      style={{ 
                        width: `${60 + Math.sin(Date.now() / 1000 + index) * 20 + (isActive ? 20 : 0)}%` 
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Left Terminal */}
      <div className="absolute bottom-0 left-0 w-80 h-80">
        <div className="absolute bottom-4 left-4 w-64 h-64">
          <div className="w-full h-full border-l-4 border-b-4 border-cyan-400/40 rounded-bl-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-tr from-cyan-400/10 to-transparent"></div>
            
            {/* Terminal Output */}
            <div className="absolute bottom-4 left-4 text-xs text-green-400/70 font-mono space-y-1 max-h-48 overflow-hidden">
              <div className="text-cyan-400">SYSTEM LOG:</div>
              <div>{'>'} Initializing neural networks...</div>
              <div>{'>'} Loading personality matrix...</div>
              <div>{'>'} Connecting to global database...</div>
              <div>{'>'} Voice recognition: {isListening ? 'ACTIVE' : 'STANDBY'}</div>
              <div>{'>'} Speech synthesis: {isSpeaking ? 'ACTIVE' : 'READY'}</div>
              <div>{'>'} All systems: {isActive ? 'OPERATIONAL' : 'STANDBY'}</div>
              <div className="text-cyan-400">{'>'} Ready for commands...</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Right Data Stream */}
      <div className="absolute bottom-0 right-0 w-80 h-80">
        <div className="absolute bottom-4 right-4 w-64 h-64">
          <div className="w-full h-full border-r-4 border-b-4 border-cyan-400/40 rounded-br-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-tl from-cyan-400/10 to-transparent"></div>
            
            {/* Data Visualization */}
            <div className="absolute inset-4">
              <div className="text-xs text-cyan-400 mb-2">DATA STREAM</div>
              <div className="relative w-full h-full">
                {/* Animated Data Points */}
                {dataStreams.map((stream) => (
                  <div
                    key={stream.id}
                    className="absolute w-1 h-1 bg-cyan-400 rounded-full animate-pulse"
                    style={{
                      left: `${stream.x}%`,
                      top: `${stream.y}%`,
                      animationDelay: `${stream.id * 0.1}s`,
                    }}
                  />
                ))}
                
                {/* Grid Lines */}
                <div className="absolute inset-0 opacity-20">
                  {[...Array(8)].map((_, i) => (
                    <div key={i}>
                      <div 
                        className="absolute w-full h-px bg-cyan-400"
                        style={{ top: `${(i + 1) * 12.5}%` }}
                      />
                      <div 
                        className="absolute h-full w-px bg-cyan-400"
                        style={{ left: `${(i + 1) * 12.5}%` }}
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Central Holographic Display */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="relative w-96 h-96">
          {/* Outer Holographic Ring */}
          {[1, 2, 3, 4, 5].map((ring) => (
            <div
              key={ring}
              className="absolute border border-cyan-400/20 rounded-full animate-spin"
              style={{
                width: `${ring * 20}%`,
                height: `${ring * 20}%`,
                top: `${50 - (ring * 10)}%`,
                left: `${50 - (ring * 10)}%`,
                animationDuration: `${10 + ring * 2}s`,
                animationDirection: ring % 2 === 0 ? 'reverse' : 'normal',
                boxShadow: isActive
                  ? `0 0 ${ring * 2}px rgba(6, 182, 212, ${pulseIntensity / ring})`
                  : "none",
              }}
            />
          ))}

          {/* Central Radar Sweep */}
          {isActive && (
            <>
              <div
                className="absolute w-48 h-0.5 bg-gradient-to-r from-cyan-400 via-cyan-300 to-transparent origin-left top-1/2 left-1/2"
                style={{
                  transform: `rotate(${radarAngle}deg)`,
                  boxShadow: `0 0 20px rgba(6, 182, 212, ${pulseIntensity})`,
                }}
              />
              <div
                className="absolute w-32 h-0.5 bg-gradient-to-r from-blue-400 to-transparent origin-left top-1/2 left-1/2"
                style={{
                  transform: `rotate(${radarAngle + 120}deg)`,
                  boxShadow: `0 0 15px rgba(59, 130, 246, ${pulseIntensity * 0.7})`,
                }}
              />
              <div
                className="absolute w-24 h-0.5 bg-gradient-to-r from-purple-400 to-transparent origin-left top-1/2 left-1/2"
                style={{
                  transform: `rotate(${radarAngle + 240}deg)`,
                  boxShadow: `0 0 10px rgba(147, 51, 234, ${pulseIntensity * 0.5})`,
                }}
              />
            </>
          )}

          {/* Center Core */}
          <div
            className="absolute w-8 h-8 bg-cyan-400 rounded-full top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
            style={{
              boxShadow: isActive 
                ? `0 0 30px rgba(6, 182, 212, ${pulseIntensity}), inset 0 0 20px rgba(6, 182, 212, ${pulseIntensity * 0.5})`
                : "none",
            }}
          >
            <div className="absolute inset-1 bg-white/20 rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>

      {/* Advanced Scanning Effects */}
      {isActive && (
        <>
          {/* Horizontal Scan Lines */}
          <div className="absolute inset-0">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="absolute w-full h-px bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent animate-pulse"
                style={{
                  top: `${20 + i * 15}%`,
                  animationDelay: `${i * 0.5}s`,
                  animationDuration: '3s',
                }}
              />
            ))}
          </div>

          {/* Vertical Scan Lines */}
          <div className="absolute inset-0">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="absolute h-full w-px bg-gradient-to-b from-transparent via-cyan-400/30 to-transparent animate-pulse"
                style={{
                  left: `${20 + i * 15}%`,
                  animationDelay: `${i * 0.3}s`,
                  animationDuration: '2.5s',
                }}
              />
            ))}
          </div>

          {/* Floating Particles */}
          <div className="absolute inset-0">
            {[...Array(30)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 bg-cyan-400/60 rounded-full animate-ping"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`,
                  animationDuration: `${2 + Math.random() * 3}s`,
                }}
              />
            ))}
          </div>
        </>
      )}

      {/* Status Indicators */}
      <div className="absolute top-1/2 left-4 transform -translate-y-1/2 space-y-4">
        {[
          { label: 'NEURAL', active: isActive },
          { label: 'VOICE', active: isListening || isSpeaking },
          { label: 'QUANTUM', active: isActive },
          { label: 'SECURE', active: true },
        ].map((status, index) => (
          <div key={status.label} className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${
              status.active 
                ? 'bg-green-400 animate-pulse shadow-lg shadow-green-400/50' 
                : 'bg-gray-600'
            }`} />
            <span className="text-xs text-cyan-400/70 font-mono">{status.label}</span>
          </div>
        ))}
      </div>

      {/* Right Side Status */}
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2 space-y-4 text-right">
        {[
          { label: 'MATRIX', value: '99.7%' },
          { label: 'SYNC', value: 'LOCKED' },
          { label: 'POWER', value: 'OPTIMAL' },
          { label: 'SHIELD', value: 'ACTIVE' },
        ].map((stat, index) => (
          <div key={stat.label} className="text-xs text-cyan-400/70 font-mono">
            <div>{stat.label}</div>
            <div className="text-green-400">{stat.value}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// Default export for compatibility
export default ProHUD
