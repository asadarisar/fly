"use client"

interface IronManHelmetProps {
  isActive?: boolean
  className?: string
}

export function IronManHelmet({ isActive = false, className = "" }: IronManHelmetProps) {
  return (
    <div className={`relative ${className}`}>
      {/* Iron Man Helmet SVG */}
      <svg
        width="80"
        height="80"
        viewBox="0 0 100 100"
        className={`transition-all duration-300 ${
          isActive ? "drop-shadow-[0_0_10px_rgba(6,182,212,0.8)]" : "opacity-60"
        }`}
      >
        {/* Helmet Outline */}
        <path
          d="M50 10 C30 10, 15 25, 15 45 L15 70 C15 80, 25 90, 35 90 L65 90 C75 90, 85 80, 85 70 L85 45 C85 25, 70 10, 50 10 Z"
          fill={isActive ? "#06b6d4" : "#6b7280"}
          stroke={isActive ? "#22d3ee" : "#9ca3af"}
          strokeWidth="2"
        />

        {/* Face Plate */}
        <path
          d="M50 20 C35 20, 25 30, 25 45 L25 65 C25 70, 30 75, 35 75 L65 75 C70 75, 75 70, 75 65 L75 45 C75 30, 65 20, 50 20 Z"
          fill={isActive ? "#0891b2" : "#4b5563"}
        />

        {/* Eye Slits */}
        <ellipse
          cx="40"
          cy="45"
          rx="8"
          ry="4"
          fill={isActive ? "#fbbf24" : "#6b7280"}
          className={isActive ? "animate-pulse" : ""}
        />
        <ellipse
          cx="60"
          cy="45"
          rx="8"
          ry="4"
          fill={isActive ? "#fbbf24" : "#6b7280"}
          className={isActive ? "animate-pulse" : ""}
        />

        {/* Mouth Vent */}
        <rect
          x="45"
          y="55"
          width="10"
          height="8"
          rx="2"
          fill={isActive ? "#0891b2" : "#4b5563"}
          stroke={isActive ? "#22d3ee" : "#6b7280"}
          strokeWidth="1"
        />

        {/* Side Vents */}
        <rect x="20" y="50" width="3" height="15" rx="1" fill={isActive ? "#0891b2" : "#4b5563"} />
        <rect x="77" y="50" width="3" height="15" rx="1" fill={isActive ? "#0891b2" : "#4b5563"} />
      </svg>

      {/* Glow Effect */}
      {isActive && <div className="absolute inset-0 rounded-full bg-cyan-400/20 blur-xl animate-pulse"></div>}
    </div>
  )
}
