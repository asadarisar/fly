"use client"

import { useEffect, useState } from "react"

interface JarvisHUDProps {
  isActive?: boolean
  isListening?: boolean
  isSpeaking?: boolean
}

export function JarvisHUD({ isActive = false, isListening = false, isSpeaking = false }: JarvisHUDProps) {
  const [radarAngle, setRadarAngle] = useState(0)
  const [pulseIntensity, setPulseIntensity] = useState(0.3)

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        setRadarAngle((prev) => (prev + 2) % 360)
      }, 50)
      return () => clearInterval(interval)
    }
  }, [isActive])

  useEffect(() => {
    if (isSpeaking) {
      setPulseIntensity(0.9)
    } else if (isListening) {
      setPulseIntensity(0.7)
    } else if (isActive) {
      setPulseIntensity(0.5)
    } else {
      setPulseIntensity(0.3)
    }
  }, [isActive, isListening, isSpeaking])

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {/* Corner HUD Elements */}
      <div className="absolute top-4 left-4">
        <div className="w-32 h-32 border-l-2 border-t-2 border-cyan-400/30 rounded-tl-lg"></div>
        <div className="absolute top-2 left-2 text-xs text-cyan-400/70">
          <div>STATUS: {isActive ? "ONLINE" : "STANDBY"}</div>
          <div>MODE: {isSpeaking ? "OUTPUT" : isListening ? "INPUT" : "READY"}</div>
        </div>
      </div>

      <div className="absolute top-4 right-4">
        <div className="w-32 h-32 border-r-2 border-t-2 border-cyan-400/30 rounded-tr-lg"></div>
        <div className="absolute top-2 right-2 text-xs text-cyan-400/70 text-right">
          <div>FLY AI v2.0</div>
          <div>ASAD ARISAR</div>
        </div>
      </div>

      <div className="absolute bottom-4 left-4">
        <div className="w-32 h-32 border-l-2 border-b-2 border-cyan-400/30 rounded-bl-lg"></div>
        <div className="absolute bottom-2 left-2 text-xs text-cyan-400/70">
          <div>SYSTEMS: NOMINAL</div>
          <div>POWER: 100%</div>
        </div>
      </div>

      <div className="absolute bottom-4 right-4">
        <div className="w-32 h-32 border-r-2 border-b-2 border-cyan-400/30 rounded-br-lg"></div>
        <div className="absolute bottom-2 right-2 text-xs text-cyan-400/70 text-right">
          <div>{new Date().toLocaleTimeString()}</div>
          <div>{new Date().toLocaleDateString()}</div>
        </div>
      </div>

      {/* Central Radar Display */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="relative w-64 h-64">
          {/* Radar Circles */}
          {[1, 2, 3, 4].map((ring) => (
            <div
              key={ring}
              className="absolute border border-cyan-400/20 rounded-full"
              style={{
                width: `${ring * 16}px`,
                height: `${ring * 16}px`,
                top: `calc(50% - ${ring * 8}px)`,
                left: `calc(50% - ${ring * 8}px)`,
                boxShadow: isActive
                  ? `0 0 ${ring * 2}px rgba(6, 182, 212, ${pulseIntensity / ring})`
                  : "none",
              }}
            />
          ))}

          {/* Radar Sweep */}
          {isActive && (
            <div
              className="absolute w-32 h-0.5 bg-gradient-to-r from-cyan-400 to-transparent origin-left top-1/2 left-1/2"
              style={{
                transform: `rotate(${radarAngle}deg)`,
                boxShadow: `0 0 10px rgba(6, 182, 212, ${pulseIntensity})`,
              }}
            />
          )}

          {/* Center Dot */}
          <div
            className="absolute w-2 h-2 bg-cyan-400 rounded-full top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
            style={{
              boxShadow: isActive ? `0 0 10px rgba(6, 182, 212, ${pulseIntensity})` : "none",
            }}
          />
        </div>
      </div>

      {/* Scanning Lines */}
      {isActive && (
        <>
          <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent animate-pulse" />
          <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent animate-pulse" />
          <div className="absolute top-0 left-0 w-0.5 h-full bg-gradient-to-b from-transparent via-cyan-400/30 to-transparent animate-pulse" />
          <div className="absolute top-0 right-0 w-0.5 h-full bg-gradient-to-b from-transparent via-cyan-400/30 to-transparent animate-pulse" />
        </>
      )}

      {/* Particle Effects */}
      {isActive && (
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400/40 rounded-full animate-ping"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}
