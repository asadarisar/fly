"use client"

import { useState } from "react"
import { Settings, Volume2, VolumeX, Mic, Shield, Palette, User, X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"

interface SettingsPanelProps {
  isOpen: boolean
  onClose: () => void
  voiceVolume: number
  onVolumeChange: (volume: number) => void
  personality: string
  onPersonalityChange: (personality: string) => void
}

export function SettingsPanel({
  isOpen,
  onClose,
  voiceVolume,
  onVolumeChange,
  personality,
  onPersonalityChange,
}: SettingsPanelProps) {
  const [activeTab, setActiveTab] = useState("voice")

  if (!isOpen) return null

  const personalities = [
    { id: "friendly", name: "Friendly", description: "Warm and helpful assistant" },
    { id: "professional", name: "Professional", description: "Formal and business-like" },
    { id: "sarcastic", name: "Sarcastic", description: "Witty and Tony Stark-like" },
  ]

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
      <Card className="bg-black/90 border-cyan-500/30 backdrop-blur-md w-full max-w-2xl max-h-[80vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Settings className="w-6 h-6 text-cyan-400" />
              <h2 className="text-xl font-bold text-cyan-400">JARVIS Settings</h2>
            </div>
            <Button
              onClick={onClose}
              className="bg-transparent hover:bg-red-600/20 text-red-400 p-2"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mb-6">
            {[
              { id: "voice", label: "Voice", icon: Volume2 },
              { id: "personality", label: "Personality", icon: User },
              { id: "permissions", label: "Permissions", icon: Shield },
              { id: "appearance", label: "Appearance", icon: Palette },
            ].map((tab) => (
              <Button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 ${
                  activeTab === tab.id
                    ? "bg-cyan-600/30 border-cyan-400 text-cyan-100"
                    : "bg-gray-600/20 border-gray-500/30 text-gray-300 hover:bg-gray-600/30"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </Button>
            ))}
          </div>

          {/* Voice Settings */}
          {activeTab === "voice" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-cyan-300 mb-4">Voice Control</h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-cyan-200 mb-2">
                      Voice Volume: {voiceVolume}%
                    </label>
                    <div className="flex items-center gap-4">
                      <VolumeX className="w-4 h-4 text-gray-400" />
                      <Slider
                        value={[voiceVolume]}
                        onValueChange={(value) => onVolumeChange(value[0])}
                        max={100}
                        step={5}
                        className="flex-1"
                      />
                      <Volume2 className="w-4 h-4 text-cyan-400" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-600/30">
                      <h4 className="font-medium text-cyan-300 mb-2">Voice Input</h4>
                      <p className="text-sm text-gray-300">Click microphone to start listening</p>
                      <div className="mt-2">
                        <span className="text-xs text-green-400">✓ Manual Activation</span>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-600/30">
                      <h4 className="font-medium text-cyan-300 mb-2">Voice Commands</h4>
                      <p className="text-sm text-gray-300">Control apps and system functions</p>
                      <div className="mt-2">
                        <span className="text-xs text-green-400">✓ Enabled</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Personality Settings */}
          {activeTab === "personality" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-cyan-300 mb-4">AI Personality</h3>
                
                <div className="space-y-3">
                  {personalities.map((p) => (
                    <div
                      key={p.id}
                      className={`p-4 rounded-lg border cursor-pointer transition-all ${
                        personality === p.id
                          ? "bg-cyan-600/20 border-cyan-400 text-cyan-100"
                          : "bg-gray-800/50 border-gray-600/30 text-gray-300 hover:bg-gray-700/50"
                      }`}
                      onClick={() => onPersonalityChange(p.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{p.name}</h4>
                          <p className="text-sm opacity-70">{p.description}</p>
                        </div>
                        {personality === p.id && (
                          <div className="w-4 h-4 bg-cyan-400 rounded-full"></div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-blue-900/20 border border-blue-500/30 rounded-lg">
                  <h4 className="font-medium text-blue-300 mb-2">Preview Response</h4>
                  <p className="text-sm text-blue-100">
                    {personality === "friendly" && "Hello! I'm here to help you with anything you need. How can I assist you today?"}
                    {personality === "professional" && "Good day. I am ready to assist you with your requests. Please specify how I may be of service."}
                    {personality === "sarcastic" && "Well, well, well. Look who needs my help again. What can I do for you this time?"}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Permissions Settings */}
          {activeTab === "permissions" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-cyan-300 mb-4">App Permissions</h3>
                
                <div className="space-y-4">
                  {[
                    { name: "Microphone Access", description: "Required for voice commands", enabled: true },
                    { name: "System Control", description: "Open apps and files", enabled: true },
                    { name: "Keyboard Input", description: "Type text on command", enabled: true },
                    { name: "Internet Access", description: "Search and real-time data", enabled: true },
                    { name: "Location Services", description: "Weather and local information", enabled: false },
                  ].map((permission, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg border border-gray-600/30">
                      <div>
                        <h4 className="font-medium text-cyan-300">{permission.name}</h4>
                        <p className="text-sm text-gray-400">{permission.description}</p>
                      </div>
                      <div className={`w-12 h-6 rounded-full ${permission.enabled ? 'bg-green-500' : 'bg-gray-500'} relative`}>
                        <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all ${permission.enabled ? 'left-6' : 'left-0.5'}`} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Appearance Settings */}
          {activeTab === "appearance" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-cyan-300 mb-4">Visual Settings</h3>
                
                <div className="space-y-4">
                  <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-600/30">
                    <h4 className="font-medium text-cyan-300 mb-2">HUD Elements</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <label className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked className="text-cyan-400" />
                        <span className="text-gray-300">Corner Displays</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked className="text-cyan-400" />
                        <span className="text-gray-300">Radar Animation</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked className="text-cyan-400" />
                        <span className="text-gray-300">Particle Effects</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked className="text-cyan-400" />
                        <span className="text-gray-300">Scanning Lines</span>
                      </label>
                    </div>
                  </div>

                  <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-600/30">
                    <h4 className="font-medium text-cyan-300 mb-2">Color Theme</h4>
                    <div className="flex gap-3">
                      {[
                        { name: "Cyan", color: "bg-cyan-400" },
                        { name: "Blue", color: "bg-blue-400" },
                        { name: "Green", color: "bg-green-400" },
                        { name: "Purple", color: "bg-purple-400" },
                      ].map((theme) => (
                        <div
                          key={theme.name}
                          className={`w-8 h-8 ${theme.color} rounded-full cursor-pointer border-2 ${
                            theme.name === "Cyan" ? "border-white" : "border-transparent"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  )
}
