"use client"

import { useState, useEffect, useRef, useCallback } from "react"

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList
  resultIndex: number
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string
  message: string
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean
  interimResults: boolean
  lang: string
  start(): void
  stop(): void
  abort(): void
  addEventListener(type: "result", listener: (event: SpeechRecognitionEvent) => void): void
  addEventListener(type: "error", listener: (event: SpeechRecognitionErrorEvent) => void): void
  addEventListener(type: "end", listener: () => void): void
  addEventListener(type: "start", listener: () => void): void
}

declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition
    webkitSpeechRecognition: new () => SpeechRecognition
  }
}

export function useSpeechToText() {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isNetworkError, setIsNetworkError] = useState(false)
  const [listeningDuration, setListeningDuration] = useState(0)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const finalTranscriptRef = useRef("")
  const listeningTimerRef = useRef<NodeJS.Timeout | null>(null)
  const autoStopTimerRef = useRef<NodeJS.Timeout | null>(null)
  const isInitializedRef = useRef(false)
  const isStartingRef = useRef(false)
  const isStoppingRef = useRef(false)
  const maxListeningTime = 15000 // 15 seconds max listening time

  // Cleanup function
  const cleanup = useCallback(() => {
    if (listeningTimerRef.current) {
      clearInterval(listeningTimerRef.current)
      listeningTimerRef.current = null
    }
    if (autoStopTimerRef.current) {
      clearTimeout(autoStopTimerRef.current)
      autoStopTimerRef.current = null
    }
    setIsListening(false)
    setListeningDuration(0)
    isStartingRef.current = false
    isStoppingRef.current = false
  }, [])

  useEffect(() => {
    // Check if speech recognition is supported
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

      if (SpeechRecognition) {
        initializeSpeechRecognition()
      } else {
        setError("Speech recognition not supported. Text input works perfectly!")
      }
    }

    return () => {
      cleanup()
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort()
        } catch (e) {
          // Silently ignore cleanup errors
        }
      }
    }
  }, [cleanup])

  const initializeSpeechRecognition = useCallback(() => {
    try {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      const recognition = recognitionRef.current

      // Enhanced configuration for better detection
      recognition.continuous = false
      recognition.interimResults = true
      recognition.lang = "en-US"
      recognition.maxAlternatives = 1

      recognition.addEventListener("result", (event: SpeechRecognitionEvent) => {
        try {
          let finalTranscript = ""
          let interimTranscript = ""

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript
            if (event.results[i].isFinal) {
              finalTranscript += transcript
              finalTranscriptRef.current = finalTranscript
            } else {
              interimTranscript += transcript
            }
          }

          // Update transcript with final or interim results
          const currentTranscript = finalTranscript || interimTranscript
          if (currentTranscript.trim()) {
            setTranscript(currentTranscript)
            setError(null) // Clear any errors when we get results
            console.log("Voice input detected:", currentTranscript)
          }
        } catch (e) {
          console.log("Speech result processing handled")
        }
      })

      recognition.addEventListener("start", () => {
        console.log("🎤 Voice recognition started - speak now!")
        setIsListening(true)
        setError(null)
        setIsNetworkError(false)
        finalTranscriptRef.current = ""
        setListeningDuration(0)
        isStartingRef.current = false

        // Start listening duration timer
        listeningTimerRef.current = setInterval(() => {
          setListeningDuration((prev) => prev + 1)
        }, 1000)

        // Auto-stop after max listening time
        autoStopTimerRef.current = setTimeout(() => {
          console.log("Auto-stopping voice recognition after timeout")
          stopListening()
        }, maxListeningTime)
      })

      recognition.addEventListener("end", () => {
        console.log("🎤 Voice recognition ended")
        cleanup()

        // Use the final transcript if available
        if (finalTranscriptRef.current && finalTranscriptRef.current.trim()) {
          console.log("Final transcript captured:", finalTranscriptRef.current)
          setTranscript(finalTranscriptRef.current)
        } else {
          console.log("No voice input detected - try speaking louder or closer to microphone")
        }
      })

      recognition.addEventListener("error", (event: SpeechRecognitionErrorEvent) => {
        console.log(`Voice recognition handled: ${event.error}`)
      
        cleanup()

        // Show helpful messages for specific issues
        switch (event.error) {
          case "not-allowed":
            setError("🎤 Microphone access needed! Please allow microphone permissions in your browser settings.")
            break
          case "audio-capture":
            setError("🎤 Microphone not detected! Please check your microphone connection or try text input.")
            break
          case "no-speech":
            setError("🎤 No voice detected! Try speaking louder, closer to your microphone, or check microphone settings.")
            break
          case "network":
            setError("🌐 Network issue detected! Voice recognition needs internet connection.")
            setIsNetworkError(true)
            break
          default:
            // For other errors, don't show error message but log for debugging
            console.log(`Voice recognition issue: ${event.error} - try again`)
            setError(null)
            break
        }
      })

      isInitializedRef.current = true
      console.log("✅ Voice recognition initialized successfully")
    } catch (error) {
      console.log("Voice recognition initialization handled")
      setError("🎤 Voice recognition not available in this browser. Please use text input instead.")
      setIsNetworkError(false)
    }
  }, [cleanup])

  const startListening = useCallback(() => {
    // Prevent multiple start attempts
    if (isStartingRef.current || isStoppingRef.current || isListening) {
      console.log("Voice recognition already active or starting")
      return
    }

    if (!recognitionRef.current || !isInitializedRef.current) {
      console.log("Voice recognition not ready - initializing...")
      initializeSpeechRecognition()
      return
    }

    isStartingRef.current = true
    setTranscript("")
    setError(null)
    finalTranscriptRef.current = ""

    console.log("🎤 Starting voice recognition...")

    try {
      recognitionRef.current.start()
    } catch (error) {
      console.log("Voice start handled:", error)
      setError("🎤 Voice recognition failed to start. Please try again or use text input.")
      cleanup()
    }
  }, [isListening, cleanup, initializeSpeechRecognition])

  const stopListening = useCallback(() => {
    // Prevent multiple stop attempts
    if (isStoppingRef.current || !isListening) {
      return
    }

    isStoppingRef.current = true

    // Clear timers first
    cleanup()

    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop()
      } catch (error) {
        // Silently handle stop errors
        console.log("Speech stop handled")
      }
    }
  }, [isListening, cleanup])

  const resetTranscript = useCallback(() => {
    setTranscript("")
    finalTranscriptRef.current = ""
  }, [])

  const clearError = useCallback(() => {
    setError(null)
  }, [])

  const disableSpeechRecognition = useCallback(() => {
    setIsNetworkError(true)
    setError(null)
    cleanup()
    
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort()
      } catch (e) {
        // Silently ignore
      }
    }
  }, [cleanup])

  // Add visibility change handler to prevent conflicts
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && isListening) {
        stopListening()
      }
    }

    const handleBeforeUnload = () => {
      if (isListening) {
        stopListening()
      }
    }

    document.addEventListener('visibilitychange', handleVisibilityChange)
    window.addEventListener('beforeunload', handleBeforeUnload)
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      window.removeEventListener('beforeunload', handleBeforeUnload)
    }
  }, [isListening, stopListening])

  return {
    isListening,
    transcript,
    error,
    isNetworkError,
    listeningDuration,
    startListening,
    stopListening,
    resetTranscript,
    clearError,
    disableSpeechRecognition,
    isSupported: !!recognitionRef.current && !isNetworkError,
  }
}
