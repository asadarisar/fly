"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { generateSpeech } from "@/services/elevenLabsService"

export function useElevenLabsVoice() {
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [voicesLoaded, setVoicesLoaded] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null)
  const speechQueueRef = useRef<string[]>([])
  const isProcessingQueueRef = useRef(false)

  // Load voices when component mounts
  useEffect(() => {
    if ("speechSynthesis" in window) {
      const loadVoices = () => {
        const voices = speechSynthesis.getVoices()
        if (voices.length > 0) {
          setVoicesLoaded(true)
        }
      }

      // Load voices immediately if available
      loadVoices()

      // Also listen for the voiceschanged event
      speechSynthesis.addEventListener("voiceschanged", loadVoices)

      return () => {
        speechSynthesis.removeEventListener("voiceschanged", loadVoices)
      }
    }
  }, [])

  const speak = useCallback(async (text: string, useRandomVoice = false) => {
    if (!text.trim()) return

    try {
      setIsSpeaking(true)
      setError(null)

      // Stop any currently playing audio quickly
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current = null
      }

      // Try ElevenLabs with shorter timeout for faster fallback
      const audioPromise = generateSpeech(text, useRandomVoice)
      const timeoutPromise = new Promise((resolve) => setTimeout(() => resolve(new Blob()), 2000)) // 2 second timeout

      const audioBlob = (await Promise.race([audioPromise, timeoutPromise])) as Blob

      // Check if we got a valid audio blob from ElevenLabs
      if (audioBlob.size > 0) {
        const audioUrl = URL.createObjectURL(audioBlob)
        const audio = new Audio(audioUrl)
        audioRef.current = audio

        audio.addEventListener("ended", () => {
          setIsSpeaking(false)
          URL.revokeObjectURL(audioUrl)
          audioRef.current = null
        })

        audio.addEventListener("error", () => {
          URL.revokeObjectURL(audioUrl)
          audioRef.current = null
          fallbackToWebSpeech(text)
        })

        await audio.play()
      } else {
        // Immediate fallback to browser TTS
        fallbackToWebSpeech(text)
      }
    } catch (err) {
      // Silently handle speech errors and fallback
      console.log("Speech generation handled, using fallback")
      fallbackToWebSpeech(text)
    }
  }, [])

  const fallbackToWebSpeech = useCallback(
    (text: string) => {
      try {
        if (!("speechSynthesis" in window)) {
          setIsSpeaking(false)
          return
        }

        // Cancel any existing speech immediately
        speechSynthesis.cancel()

        // Detect if text contains Urdu characters
        const hasUrdu = /[\u0600-\u06FF]/.test(text)

        // Shorter text chunks for faster processing
        const maxLength = hasUrdu ? 80 : 100 // Shorter chunks for Urdu
        const textChunks = text.length > maxLength ? splitTextIntoChunks(text, maxLength) : [text]

        speechQueueRef.current = textChunks
        isProcessingQueueRef.current = true

        // Start immediately without waiting
        setTimeout(() => processNextChunk(), 50)
      } catch (err) {
        // Silently handle fallback speech errors
        console.log("Fallback speech handled")
        setIsSpeaking(false)
      }
    },
    [voicesLoaded],
  )

  const processNextChunk = useCallback(() => {
    if (!isProcessingQueueRef.current || speechQueueRef.current.length === 0) {
      setIsSpeaking(false)
      isProcessingQueueRef.current = false
      return
    }

    const chunk = speechQueueRef.current.shift()
    if (!chunk) {
      setIsSpeaking(false)
      isProcessingQueueRef.current = false
      return
    }

    try {
      // Create utterance for this chunk
      const utterance = new SpeechSynthesisUtterance(chunk)

      // Configure voice settings
      utterance.rate = 0.9
      utterance.pitch = 0.75
      utterance.volume = 0.9

      // Try to find a suitable voice based on the text language
      const voices = speechSynthesis.getVoices()
      const preferredVoice = findBestVoice(voices, chunk)

      if (preferredVoice) {
        utterance.voice = preferredVoice
      }

      utterance.onstart = () => {
        setIsSpeaking(true)
        setError(null)
      }

      utterance.onend = () => {
        // Process next chunk after a brief pause
        setTimeout(() => {
          if (isProcessingQueueRef.current) {
            processNextChunk()
          }
        }, 50)
      }

      utterance.onerror = (event) => {
        // Silently handle chunk errors and continue
        console.log(`Speech chunk handled: ${event.error}`)

        // Always try to continue with next chunk
        setTimeout(() => {
          if (isProcessingQueueRef.current) {
            processNextChunk()
          }
        }, 100)
      }

      // Store reference to current utterance
      currentUtteranceRef.current = utterance

      // Speak the chunk
      speechSynthesis.speak(utterance)
    } catch (err) {
      // Silently handle chunk processing errors
      console.log("Speech chunk processing handled")
      setTimeout(() => {
        if (isProcessingQueueRef.current) {
          processNextChunk()
        }
      }, 100)
    }
  }, [])

  const splitTextIntoChunks = useCallback((text: string, maxLength: number): string[] => {
    // Split by sentences first
    const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0)
    const chunks: string[] = []
    let currentChunk = ""

    for (const sentence of sentences) {
      const trimmedSentence = sentence.trim()
      if (currentChunk.length + trimmedSentence.length > maxLength && currentChunk.length > 0) {
        chunks.push(currentChunk.trim())
        currentChunk = trimmedSentence
      } else {
        currentChunk += (currentChunk ? ". " : "") + trimmedSentence
      }
    }

    if (currentChunk.trim()) {
      chunks.push(currentChunk.trim())
    }

    // If no sentences were found, split by words
    if (chunks.length === 0) {
      const words = text.split(" ")
      let wordChunk = ""
      for (const word of words) {
        if (wordChunk.length + word.length > maxLength && wordChunk.length > 0) {
          chunks.push(wordChunk.trim())
          wordChunk = word
        } else {
          wordChunk += (wordChunk ? " " : "") + word
        }
      }
      if (wordChunk.trim()) {
        chunks.push(wordChunk.trim())
      }
    }

    return chunks.length > 0 ? chunks : [text.substring(0, maxLength)]
  }, [])

  const findBestVoice = useCallback((voices: SpeechSynthesisVoice[], text?: string) => {
    // Detect if text contains Urdu characters
    const hasUrdu = text && /[\u0600-\u06FF]/.test(text)

    if (hasUrdu) {
      // Priority for Urdu voices
      const urduVoicePreferences = [
        (v: SpeechSynthesisVoice) => v.lang.startsWith("ur"),
        (v: SpeechSynthesisVoice) => v.lang.startsWith("hi"), // Hindi as fallback
        (v: SpeechSynthesisVoice) => v.lang.startsWith("ar"), // Arabic as fallback
      ]

      for (const preference of urduVoicePreferences) {
        const voice = voices.find(preference)
        if (voice) {
          return voice
        }
      }
    }

    // Priority order for English voice selection (Bill-like characteristics)
    const voicePreferences = [
      // Prefer specific high-quality voices
      (v: SpeechSynthesisVoice) => v.name.toLowerCase().includes("david") && v.lang.startsWith("en"),
      (v: SpeechSynthesisVoice) => v.name.toLowerCase().includes("alex") && v.lang.startsWith("en"),
      (v: SpeechSynthesisVoice) => v.name.toLowerCase().includes("daniel") && v.lang.startsWith("en"),
      (v: SpeechSynthesisVoice) => v.name.toLowerCase().includes("tom") && v.lang.startsWith("en"),
      (v: SpeechSynthesisVoice) => v.name.toLowerCase().includes("male") && v.lang.startsWith("en"),
      // Fallback to any English voice
      (v: SpeechSynthesisVoice) => v.lang.startsWith("en-") && !v.name.toLowerCase().includes("female"),
      (v: SpeechSynthesisVoice) => v.lang.startsWith("en-"),
      (v: SpeechSynthesisVoice) => v.lang.startsWith("en"),
    ]

    for (const preference of voicePreferences) {
      const voice = voices.find(preference)
      if (voice) {
        return voice
      }
    }

    // Return first available voice as last resort
    return voices[0] || null
  }, [])

  const stopSpeaking = useCallback(async () => {
    // Stop processing queue
    isProcessingQueueRef.current = false
    speechQueueRef.current = []

    // Stop ElevenLabs audio if playing
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current = null
    }

    // Stop browser speech synthesis if active
    if ("speechSynthesis" in window) {
      try {
        if (speechSynthesis.speaking || speechSynthesis.pending) {
          speechSynthesis.cancel()
          // Wait for cancellation to complete
          await new Promise((resolve) => setTimeout(resolve, 100))
        }
      } catch (e) {
        // Silently handle stop errors
      }
    }

    currentUtteranceRef.current = null
    setIsSpeaking(false)
    setError(null)
  }, [])

  return {
    isSpeaking,
    error,
    speak,
    stopSpeaking,
    voicesLoaded,
  }
}
