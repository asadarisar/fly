"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Mic, MicOff, Send, Volume2, AlertCircle, X, MessageSquare, Clock, Settings, Zap, Shield, Cpu, Wifi } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { useSpeechToText } from "@/hooks/useSpeechToText"
import { useElevenLabsVoice } from "@/hooks/useElevenLabsVoice"
import { sendChatMessage } from "@/services/chatGPTService"
import { searchQuery, searchByLocation } from "@/services/searchAPI"
import { checkConfiguration } from "@/services/configService"
import { ArcReactor } from "@/components/ArcReactor"
import { IronManHelmet } from "@/components/IronManHelmet"
import ProHUD from "@/components/ProHUD"
import { SettingsPanel } from "@/components/SettingsPanel"
import { getWeatherData } from "@/services/weatherService"
import { findOwnerInfo } from "@/services/ownerInfoService"
import { openApplication, typeText } from "@/services/systemControlService"
import { getRealTimeNews, getSportsScores, getMarketData } from "@/services/realTimeDataService"

interface Message {
  id: string
  type: "user" | "assistant"
  content: string
  timestamp: Date
}

export default function FlyAIApp() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSystemActive, setIsSystemActive] = useState(false)
  const [speechDisabled, setSpeechDisabled] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [voiceVolume, setVoiceVolume] = useState(80)
  const [personality, setPersonality] = useState("friendly")
  const [systemStats, setSystemStats] = useState({ cpu: 0, memory: 0, network: 0 })
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const processingTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const [configStatus, setConfigStatus] = useState({
    openai: false,
    elevenlabs: false,
    searchapi: false,
  })

  const {
    isListening,
    transcript,
    listeningDuration,
    startListening,
    stopListening,
    resetTranscript,
    clearError,
    disableSpeechRecognition,
    error: speechError,
    isNetworkError,
    isSupported: speechSupported,
  } = useSpeechToText()

  const { isSpeaking, speak, stopSpeaking, error: voiceError, voicesLoaded } = useElevenLabsVoice()

  // Animate system stats
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemStats({
        cpu: 60 + Math.sin(Date.now() / 1000) * 20 + (isProcessing ? 15 : 0),
        memory: 45 + Math.cos(Date.now() / 1500) * 15 + (isListening ? 10 : 0),
        network: 80 + Math.sin(Date.now() / 2000) * 10 + (isSpeaking ? 15 : 0),
      })
    }, 100)
    return () => clearInterval(interval)
  }, [isProcessing, isListening, isSpeaking])

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Check configuration status on mount
  useEffect(() => {
    checkConfiguration().then(setConfigStatus)
  }, [])

  // Activate system when any interaction occurs
  useEffect(() => {
    if (messages.length > 0 || isListening || isSpeaking || isProcessing) {
      setIsSystemActive(true)
    }
  }, [messages.length, isListening, isSpeaking, isProcessing])

  // Handle voice input when speech recognition ends
  useEffect(() => {
    if (!isListening && transcript && transcript.trim().length > 0) {
      console.log("✅ Processing voice input:", transcript)

      // Clear any existing timeout
      if (processingTimeoutRef.current) {
        clearTimeout(processingTimeoutRef.current)
      }

      // Process the voice input after a short delay
      processingTimeoutRef.current = setTimeout(() => {
        handleVoiceInput(transcript)
        resetTranscript()
      }, 500)
    } else if (!isListening && !transcript) {
      console.log("⚠️ Voice recognition ended but no input detected")
    }
  }, [isListening, transcript])

  // Auto-disable speech recognition after multiple network errors
  useEffect(() => {
    if (isNetworkError && !speechDisabled) {
      // Auto-disable speech after network errors to improve UX
      setTimeout(() => {
        setSpeechDisabled(true)
        disableSpeechRecognition()
      }, 3000)
    }
  }, [isNetworkError, speechDisabled, disableSpeechRecognition])

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (processingTimeoutRef.current) {
        clearTimeout(processingTimeoutRef.current)
      }
    }
  }, [])

  const playActivationSound = () => {
    try {
      const audio = new Audio("/sounds/activation.mp3")
      audio.volume = voiceVolume / 100
      audio.play().catch(() => {}) // Silently ignore sound errors
    } catch (e) {
      // Silently ignore all sound errors
    }
  }

  const addMessage = (type: "user" | "assistant", content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      type,
      content,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, newMessage])
    return newMessage
  }

  const handleVoiceInput = async (voiceText: string) => {
    if (!voiceText.trim()) {
      console.log("Empty voice input received")
      addMessage("assistant", "🎤 I didn't catch that! Please try speaking again or type your message. What can I help you with?")
      return
    }

    console.log("🎤 Voice input received:", voiceText)
    playActivationSound()
    
    // Add a confirmation message for voice input
    addMessage("assistant", `🎤 I heard: "${voiceText}" - processing now...`)
    
    await processMessage(voiceText)
  }

  const handleTextInput = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputText.trim()) return

    const userMessage = inputText
    setInputText("")
    setIsSystemActive(true)
    await processMessage(userMessage)
  }

  const processMessage = async (message: string) => {
    console.log("Processing message:", message)
    setIsProcessing(true)

    // Add user message immediately for faster UI feedback
    addMessage("user", message)

    try {
      let response = ""
      const lowerMessage = message.toLowerCase()

      // Owner information queries
      if (lowerMessage.includes("who owns") || lowerMessage.includes("owner of") || lowerMessage.includes("founded by")) {
        console.log("Processing owner info query")
        const companyMatch = message.match(/(?:who owns|owner of|founded by)\s+([^?]+)/i)
        if (companyMatch) {
          const companyName = companyMatch[1].trim()
          response = await findOwnerInfo(companyName)
        }
      }
      // System control commands
      else if (lowerMessage.includes("open ") && !lowerMessage.includes("open ai")) {
        console.log("Processing app open command")
        const appMatch = message.match(/open\s+([^,?!.]+)/i)
        if (appMatch) {
          const appName = appMatch[1].trim()
          response = await openApplication(appName)
        }
      }
      // Type text command
      else if (lowerMessage.includes("type ")) {
        console.log("Processing type command")
        const textMatch = message.match(/type\s+(.+)/i)
        if (textMatch) {
          const textToType = textMatch[1].trim()
          response = await typeText(textToType)
        }
      }
      // Real-time news - ENHANCED
      else if (lowerMessage.includes("news") || lowerMessage.includes("headlines") || lowerMessage.includes("latest")) {
        console.log("Processing enhanced news query")
        const categoryMatch = message.match(/(technology|tech|sports|business|health|science|entertainment|world|politics|breaking)\s*news/i)
        const category = categoryMatch ? categoryMatch[1] : "general"
        
        // Show immediate feedback
        addMessage("assistant", `🔍 Searching for latest ${category} news... Please wait a moment.`)
        
        response = await getRealTimeNews(category)
      }
      // Sports scores
      else if (lowerMessage.includes("scores") || lowerMessage.includes("sports")) {
        console.log("Processing sports query")
        const sportMatch = message.match(/(football|basketball|baseball|soccer|hockey|tennis)\s+scores/i)
        const sport = sportMatch ? sportMatch[1] : "football"
        response = await getSportsScores(sport)
      }
      // Market data
      else if (lowerMessage.includes("market") || lowerMessage.includes("stocks") || lowerMessage.includes("dow jones")) {
        console.log("Processing market query")
        response = await getMarketData()
      }
      // Weather requests
      else if (/\b(weather|temperature|forecast|climate|rain|sunny|cloudy|hot|cold|موسم)\b/i.test(message)) {
        console.log("Processing weather query")
        const locationMatch = message.match(/(?:in|for|at|weather in|weather for)\s+([^,?!.]+)/i)
        const location = locationMatch ? locationMatch[1].trim() : "current location"
        response = await getWeatherInfo(message, location)
      }
      // Search queries
      else if (/\b(search|find|look up|what is|who is|where is|tell me about|تلاش)\b/i.test(message)) {
        console.log("Processing search query")
        const searchTerm = message
          .replace(/\b(search|find|look up|what is|who is|where is|tell me about|تلاش)\b/gi, "")
          .trim()

        const searchPromise =
          message.toLowerCase().includes("in ") || message.toLowerCase().includes("near ")
            ? (() => {
                const locationMatch = message.match(/(?:in|near)\s+([^,]+)/i)
                return locationMatch ? searchByLocation(searchTerm, locationMatch[1].trim()) : searchQuery(searchTerm)
              })()
            : searchQuery(searchTerm)

        const searchResults = await Promise.race([
          searchPromise,
          new Promise((resolve) =>
            setTimeout(() => resolve("Search is taking longer than expected. Let me try a different approach."), 5000),
          ),
        ])

        response =
          searchResults && typeof searchResults === "string" && searchResults.length > 0
            ? `Here's what I found: ${searchResults}`
            : "I couldn't find search results quickly. Let me help you with something else."
      } 
      // Regular chat
      else {
        console.log("Processing chat message")
        const chatPromise = sendChatMessage(message, messages.slice(-5), personality)

        response = (await Promise.race([
          chatPromise,
          new Promise((resolve) =>
            setTimeout(
              () => resolve("I'm FLY AI by ASAD ARISAR, and I'm here to help! Please try your question again."),
              8000,
            ),
          ),
        ])) as string
      }

      console.log("Generated response:", response)

      // Add assistant response immediately
      addMessage("assistant", response)

      // Start speaking immediately without waiting
      speak(response, false).catch(() => {}) // Silently handle speech errors
    } catch (error) {
      console.error("Error processing message:", error)
      const errorMessage = "I'm FLY AI and I'm ready to help! Please try your question again."
      addMessage("assistant", errorMessage)
      speak(errorMessage, false).catch(() => {}) // Silently handle speech errors
    } finally {
      setIsProcessing(false)
    }
  }

  // Add weather function
  const getWeatherInfo = async (query: string, location: string): Promise<string> => {
    try {
      return await getWeatherData(location === "current location" ? "auto" : location)
    } catch (error) {
      return `I'm having trouble getting weather information right now. Please try again or ask me something else!`
    }
  }

  const handleMicToggle = () => {
    console.log("Mic toggle clicked, isListening:", isListening)
    setIsSystemActive(true)

    if (speechDisabled || isNetworkError) {
      return
    }

    // Prevent rapid clicking
    if (isProcessing) {
      return
    }

    if (isListening) {
      stopListening()
    } else {
      // Clear any existing errors before starting
      clearError()
      // Add small delay to prevent conflicts
      setTimeout(() => {
        startListening()
      }, 100)
    }
  }

  const handleDisableSpeech = () => {
    setSpeechDisabled(true)
    disableSpeechRecognition()
    clearError()
  }

  const focusTextInput = () => {
    inputRef.current?.focus()
  }

  return (
    <div className="min-h-screen bg-black text-cyan-400 font-mono overflow-hidden relative">
      {/* Advanced Pro HUD Background */}
      <ProHUD isActive={isSystemActive} isListening={isListening} isSpeaking={isSpeaking} />

      {/* Enhanced Animated Background */}
      <div className="fixed inset-0 z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-purple-900/30 to-cyan-900/30"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(6,182,212,0.15),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(147,51,234,0.1),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[conic-gradient(from_0deg_at_50%_50%,rgba(6,182,212,0.1),rgba(147,51,234,0.1),rgba(6,182,212,0.1))] animate-spin" style={{ animationDuration: '20s' }}></div>
      </div>

      <div className="relative z-20 container mx-auto px-4 py-4 max-w-7xl">
        {/* Enhanced Top Section */}
        <div className="flex justify-between items-start mb-6">
          {/* Left Side - Advanced Input Controls */}
          <div className="flex-1 max-w-3xl">
            {/* Pro Input Controls */}
            <div className="flex gap-3 mb-4">
              {/* Enhanced Text Input */}
              <form onSubmit={handleTextInput} className="flex-1 flex gap-2">
                <div className="relative flex-1">
                  <Input
                    ref={inputRef}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="🚀 NEURAL INTERFACE ACTIVE - Try: 'Latest tech news', 'Open YouTube', 'Who owns Tesla?' 🎯"
                    className="bg-black/70 border-2 border-cyan-500/50 text-cyan-100 placeholder-cyan-300/60 focus:border-cyan-400 focus:shadow-lg focus:shadow-cyan-400/20 pr-12 h-12 text-sm backdrop-blur-sm"
                    disabled={isProcessing}
                  />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                    <Zap className="w-4 h-4 text-cyan-400 animate-pulse" />
                  </div>
                </div>
                <Button
                  type="submit"
                  disabled={!inputText.trim() || isProcessing}
                  className="bg-gradient-to-r from-cyan-600/30 to-blue-600/30 border-2 border-cyan-500/50 hover:from-cyan-600/50 hover:to-blue-600/50 text-cyan-100 h-12 px-6 backdrop-blur-sm shadow-lg shadow-cyan-400/20"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </form>

              {/* Enhanced Voice Controls */}
              {speechSupported && !speechDisabled && !isNetworkError ? (
                <Button
                  onClick={handleMicToggle}
                  disabled={isProcessing}
                  className={`h-12 px-6 backdrop-blur-sm shadow-lg transition-all duration-300 ${
                    isListening
                      ? "bg-gradient-to-r from-red-600/40 to-pink-600/40 border-2 border-red-500/50 hover:from-red-600/60 hover:to-pink-600/60 text-red-100 animate-pulse shadow-red-400/30"
                      : "bg-gradient-to-r from-green-600/30 to-emerald-600/30 border-2 border-green-500/50 hover:from-green-600/50 hover:to-emerald-600/50 text-green-100 shadow-green-400/20"
                  }`}
                  title={isListening ? "Neural link active - speak now!" : "Activate neural voice interface"}
                >
                  {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </Button>
              ) : (
                <Button
                  disabled
                  className="bg-gray-600/30 border-2 border-gray-500/30 text-gray-400 cursor-not-allowed h-12 px-6 backdrop-blur-sm"
                  title="Voice interface offline - neural text mode active"
                >
                  <MicOff className="w-5 h-5" />
                </Button>
              )}

              {/* Pro Control Buttons */}
              <Button
                onClick={() => setShowSettings(true)}
                className="bg-gradient-to-r from-purple-600/30 to-violet-600/30 border-2 border-purple-500/50 hover:from-purple-600/50 hover:to-violet-600/50 text-purple-100 h-12 px-6 backdrop-blur-sm shadow-lg shadow-purple-400/20"
                title="Access quantum settings matrix"
              >
                <Settings className="w-5 h-5" />
              </Button>

              <Button
                onClick={focusTextInput}
                className="bg-gradient-to-r from-blue-600/30 to-indigo-600/30 border-2 border-blue-500/50 hover:from-blue-600/50 hover:to-indigo-600/50 text-blue-100 h-12 px-6 backdrop-blur-sm shadow-lg shadow-blue-400/20"
                title="Focus neural text interface"
              >
                <MessageSquare className="w-5 h-5" />
              </Button>

              {/* Stop Speaking */}
              {isSpeaking && (
                <Button
                  onClick={stopSpeaking}
                  className="bg-gradient-to-r from-orange-600/30 to-red-600/30 border-2 border-orange-500/50 hover:from-orange-600/50 hover:to-red-600/50 text-orange-100 h-12 px-6 backdrop-blur-sm shadow-lg shadow-orange-400/20 animate-pulse"
                >
                  <Volume2 className="w-5 h-5" />
                </Button>
              )}
            </div>

            {/* Enhanced Voice Transcript Display */}
            {(isListening || transcript) && !speechDisabled && (
              <Card className="bg-black/80 border-2 border-yellow-500/50 backdrop-blur-md mb-4 shadow-xl shadow-yellow-400/20">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <Mic className={`w-6 h-6 text-yellow-400 ${isListening ? "animate-pulse" : ""}`} />
                        {isListening && (
                          <div className="absolute -inset-1 bg-yellow-400/20 rounded-full animate-ping"></div>
                        )}
                      </div>
                      <span className="text-yellow-400 text-lg font-bold">
                        {isListening ? "🎤 NEURAL VOICE LINK ACTIVE" : "VOICE INPUT CAPTURED"}
                      </span>
                    </div>
                    {isListening && (
                      <div className="flex items-center gap-2 text-yellow-300 bg-yellow-400/10 px-3 py-1 rounded-full">
                        <Clock className="w-4 h-4" />
                        <span className="font-mono">{listeningDuration}s</span>
                      </div>
                    )}
                  </div>
                  <p className="text-yellow-100 text-lg mb-3">
                    {transcript || (isListening ? "Neural interface listening... Speak your command now!" : "Voice command ready for processing")}
                  </p>
                  {isListening && (
                    <div className="text-sm text-yellow-300/80 space-y-2 bg-yellow-400/5 p-4 rounded-lg border border-yellow-400/20">
                      <p className="font-semibold">🧠 NEURAL VOICE OPTIMIZATION TIPS:</p>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <p>• Speak clearly and confidently</p>
                        <p>• Stay within 2 feet of microphone</p>
                        <p>• Try: "Latest tech news"</p>
                        <p>• Try: "Open YouTube"</p>
                        <p>• Try: "Who owns Apple?"</p>
                        <p>• Fallback: Use text interface</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            )}

            {/* Enhanced Error Display */}
            {speechError && speechError.includes("Microphone") && !speechDisabled && (
              <Card className="bg-red-900/30 border-2 border-red-500/50 backdrop-blur-md mb-4 shadow-xl shadow-red-400/20">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-6 h-6 text-red-400" />
                      <span className="text-red-400 text-lg font-bold">NEURAL INTERFACE ERROR</span>
                    </div>
                    <Button
                      onClick={clearError}
                      size="sm"
                      className="bg-transparent hover:bg-red-600/20 text-red-400 p-2"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-red-100 mb-4">{speechError}</p>
                  <div className="flex gap-3">
                    <Button
                      onClick={handleDisableSpeech}
                      size="sm"
                      className="bg-blue-600/30 hover:bg-blue-600/50 text-blue-100 px-4 py-2 border border-blue-500/50"
                    >
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Activate Text Mode
                    </Button>
                    <Button
                      onClick={focusTextInput}
                      size="sm"
                      className="bg-green-600/30 hover:bg-green-600/50 text-green-100 px-4 py-2 border border-green-500/50"
                    >
                      Focus Neural Text
                    </Button>
                  </div>
                </div>
              </Card>
            )}
          </div>

          {/* Enhanced Right Side - Pro Branding */}
          <div className="text-right ml-8">
            <div className="mb-4 p-6 bg-black/60 border-2 border-cyan-500/30 rounded-xl backdrop-blur-md shadow-xl shadow-cyan-400/20">
              <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 mb-2">
                FLY AI
              </h1>
              <p className="text-cyan-300/80 text-lg font-semibold">QUANTUM NEURAL SYSTEM</p>
              <div className="text-sm text-cyan-300/60 mt-3 space-y-1">
                <p className="font-bold text-cyan-200">CREATOR: ASAD ARISAR</p>
                <p>🧠 Advanced AI Matrix</p>
                <p>⚡ Quantum Processing Core</p>
                <p className="text-purple-300/70 mt-2">
                  Mode: {personality.charAt(0).toUpperCase() + personality.slice(1)}
                </p>
              </div>
              
              {/* System Stats */}
              <div className="mt-4 space-y-2">
                {[
                  { label: 'CPU', value: systemStats.cpu, icon: Cpu },
                  { label: 'NET', value: systemStats.network, icon: Wifi },
                  { label: 'AI', value: systemStats.memory, icon: Shield },
                ].map((stat) => (
                  <div key={stat.label} className="flex items-center gap-2 text-xs">
                    <stat.icon className="w-3 h-3 text-cyan-400" />
                    <span className="w-8 text-cyan-300">{stat.label}</span>
                    <div className="w-16 h-1.5 bg-gray-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full transition-all duration-500"
                        style={{ width: `${Math.max(0, Math.min(100, stat.value))}%` }}
                      />
                    </div>
                    <span className="text-xs text-cyan-400">{Math.round(stat.value)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Center Section */}
        <div className="text-center mb-8">
          {/* Pro Iron Man Helmet */}
          <div className="flex justify-center mb-6">
            <div className="relative">
              <IronManHelmet isActive={isSystemActive} className="transform scale-125" />
              {isSystemActive && (
                <div className="absolute inset-0 bg-cyan-400/20 rounded-full blur-xl animate-pulse"></div>
              )}
            </div>
          </div>

          {/* Enhanced Arc Reactor */}
          <div className="relative">
            <ArcReactor isActive={isSystemActive} isListening={isListening} isSpeaking={isSpeaking} />
            {isSystemActive && (
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/10 via-blue-400/10 to-purple-400/10 rounded-full blur-2xl animate-pulse"></div>
            )}
          </div>

          {/* Enhanced Configuration Status */}
          <div className="mt-6 p-4 bg-black/60 border border-cyan-500/30 rounded-xl backdrop-blur-md shadow-lg">
            <div className="flex justify-center items-center gap-6 flex-wrap text-sm">
              <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${configStatus.openai ? "bg-green-400/20 border border-green-400/30" : "bg-red-400/20 border border-red-400/30"}`}>
                <div className={`w-2 h-2 rounded-full ${configStatus.openai ? "bg-green-400 animate-pulse" : "bg-red-400"}`}></div>
                <span className={configStatus.openai ? "text-green-300" : "text-red-300"}>
                  ChatGPT: {configStatus.openai ? "QUANTUM READY" : "OFFLINE"}
                </span>
              </div>
              
              <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${configStatus.elevenlabs ? "bg-green-400/20 border border-green-400/30" : "bg-yellow-400/20 border border-yellow-400/30"}`}>
                <div className={`w-2 h-2 rounded-full ${configStatus.elevenlabs ? "bg-green-400 animate-pulse" : "bg-yellow-400 animate-pulse"}`}></div>
                <span className={configStatus.elevenlabs ? "text-green-300" : "text-yellow-300"}>
                  Voice: {configStatus.elevenlabs ? "NEURAL READY" : voicesLoaded ? "BROWSER MODE" : "LOADING"}
                </span>
              </div>
              
              <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${configStatus.searchapi ? "bg-green-400/20 border border-green-400/30" : "bg-red-400/20 border border-red-400/30"}`}>
                <div className={`w-2 h-2 rounded-full ${configStatus.searchapi ? "bg-green-400 animate-pulse" : "bg-red-400"}`}></div>
                <span className={configStatus.searchapi ? "text-green-300" : "text-red-300"}>
                  Search: {configStatus.searchapi ? "GLOBAL NET" : "LIMITED"}
                </span>
              </div>
              
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-green-400/20 border border-green-400/30">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                <span className="text-green-300 font-bold">TEXT: ALWAYS READY ⚡</span>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Chat Messages */}
        <Card className="bg-black/70 border-2 border-cyan-500/50 backdrop-blur-md mb-6 h-96 overflow-y-auto shadow-2xl shadow-cyan-400/20">
          <div className="p-6 space-y-6">
            <div className="text-center text-cyan-300/60 py-12">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 mb-3">
                  🚀 FLY AI QUANTUM NEURAL SYSTEM ONLINE!
                </h2>
                <p className="text-xl text-green-400 font-semibold mb-4">💫 INSANE PRO MODE ACTIVATED!</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm text-cyan-400/80 max-w-2xl mx-auto">
                <div className="bg-cyan-400/5 p-4 rounded-lg border border-cyan-400/20">
                  <p className="font-semibold mb-2">🎤 NEURAL VOICE</p>
                  <p>Click microphone for instant voice commands</p>
                </div>
                <div className="bg-blue-400/5 p-4 rounded-lg border border-blue-400/20">
                  <p className="font-semibold mb-2">📱 QUANTUM COMMANDS</p>
                  <p>"Latest tech news", "Open YouTube"</p>
                </div>
                <div className="bg-purple-400/5 p-4 rounded-lg border border-purple-400/20">
                  <p className="font-semibold mb-2">⌨️ NEURAL TEXT</p>
                  <p>Type any command or question</p>
                </div>
                <div className="bg-green-400/5 p-4 rounded-lg border border-green-400/20">
                  <p className="font-semibold mb-2">🎭 AI PERSONALITY</p>
                  <p>{personality.charAt(0).toUpperCase() + personality.slice(1)} mode active</p>
                </div>
              </div>
              
              <p className="text-green-400 mt-6 text-lg font-bold">
                ✨ INSANE PRO INTERFACE - ZERO INTERRUPTIONS! 🎬
              </p>
            </div>

            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-md px-6 py-4 rounded-xl backdrop-blur-sm shadow-lg ${
                    message.type === "user"
                      ? "bg-gradient-to-r from-cyan-600/30 to-blue-600/30 border-2 border-cyan-500/50 text-cyan-100 shadow-cyan-400/20"
                      : "bg-gradient-to-r from-blue-600/30 to-purple-600/30 border-2 border-blue-500/50 text-blue-100 shadow-blue-400/20"
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap font-medium">{message.content}</p>
                  <p className="text-xs opacity-60 mt-2 font-mono">{message.timestamp.toLocaleTimeString()}</p>
                </div>
              </div>
            ))}

            {isProcessing && (
              <div className="flex justify-start">
                <div className="bg-gradient-to-r from-blue-600/30 to-purple-600/30 border-2 border-blue-500/50 text-blue-100 max-w-md px-6 py-4 rounded-xl backdrop-blur-sm shadow-lg shadow-blue-400/20">
                  <div className="flex items-center gap-3">
                    <div className="flex gap-1">
                      <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce"></div>
                      <div
                        className="w-3 h-3 bg-blue-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-3 h-3 bg-blue-400 rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                    <span className="text-sm font-semibold">QUANTUM NEURAL PROCESSING...</span>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </Card>

        {/* Enhanced Status Bar */}
        <div className="text-center">
          <div className="inline-block bg-black/60 border-2 border-cyan-500/30 rounded-xl px-8 py-4 backdrop-blur-md shadow-xl shadow-cyan-400/20">
            <p className="text-lg font-bold text-cyan-300 mb-2">
              QUANTUM SYSTEM STATUS:{" "}
              {isListening
                ? `🎤 NEURAL VOICE ACTIVE (${listeningDuration}s) - SPEAK NOW!`
                : isSpeaking
                  ? "🔊 AI VOICE OUTPUT STREAMING"
                  : isProcessing
                    ? "⚡ QUANTUM NEURAL PROCESSING"
                    : isSystemActive
                      ? "✅ ALL SYSTEMS OPTIMAL"
                      : "⏸️ STANDBY MODE"}
            </p>
            <p className="text-green-400 font-bold text-lg">
              💫 INSANE PRO JARVIS INTERFACE - NEURAL COMMANDS READY! 🚀
            </p>
          </div>
        </div>
      </div>

      {/* Enhanced Settings Panel */}
      <SettingsPanel
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        voiceVolume={voiceVolume}
        onVolumeChange={setVoiceVolume}
        personality={personality}
        onPersonalityChange={setPersonality}
      />
    </div>
  )
}
