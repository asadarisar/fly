"use server"

interface NewsItem {
  title: string
  description: string
  url: string
  publishedAt: string
  source: string
}

interface SportsScore {
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  status: string
  league: string
}

export async function getRealTimeNews(category: string = "general"): Promise<string> {
  try {
    const apiKey = process.env.SEARCHAPI_KEY

    if (!apiKey) {
      return "Real-time news requires SearchAPI configuration. Please add your SEARCHAPI_KEY to enable this feature."
    }

    // Enhanced search queries for better news results
    const currentDate = new Date().toISOString().split('T')[0]
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    
    const searchQueries = [
      `latest ${category} news today breaking ${currentDate}`,
      `${category} news headlines today ${currentDate}`,
      `breaking ${category} news ${yesterday} ${currentDate}`,
      `recent ${category} updates news`,
      `${category} news this week latest`
    ]

    let bestResults = ""
    
    for (const query of searchQueries) {
      try {
        const searchParams = new URLSearchParams({
          api_key: apiKey,
          engine: "google",
          q: query,
          num: "8",
          tbm: "nws" // News search specifically
        })

        console.log(`Searching for news: ${query}`)

        const response = await fetch(`https://www.searchapi.io/api/v1/search?${searchParams.toString()}`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        })

        if (response.ok) {
          const data = await response.json()
          const newsResults = data.news_results || data.organic_results || []

          if (newsResults.length > 0) {
            let newsReport = `**🔥 Latest ${category.charAt(0).toUpperCase() + category.slice(1)} News:**\n\n`
            
            newsResults.slice(0, 5).forEach((item: any, index: number) => {
              const title = item.title || item.snippet || "Breaking News"
              const snippet = item.snippet || item.description || ""
              const source = item.source || item.displayed_link || "News Source"
              const date = item.date || "Recent"
              
              newsReport += `**${index + 1}. ${title}**\n`
              if (snippet && snippet !== title) {
                newsReport += `   📰 ${snippet.substring(0, 150)}${snippet.length > 150 ? '...' : ''}\n`
              }
              newsReport += `   📅 ${date} | 🏢 ${source}\n\n`
            })

            console.log(`Found ${newsResults.length} news results`)
            return newsReport
          }
        }
      } catch (queryError) {
        console.log(`Query failed: ${query}`, queryError)
        continue
      }
    }

    // Fallback: Try general search without news filter
    try {
      const fallbackQuery = `${category} news today latest updates`
      const searchParams = new URLSearchParams({
        api_key: apiKey,
        engine: "google",
        q: fallbackQuery,
        num: "5"
      })

      const response = await fetch(`https://www.searchapi.io/api/v1/search?${searchParams.toString()}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        const results = data.organic_results || []

        if (results.length > 0) {
          let newsReport = `**📰 ${category.charAt(0).toUpperCase() + category.slice(1)} Updates:**\n\n`
          
          results.slice(0, 4).forEach((item: any, index: number) => {
            newsReport += `**${index + 1}. ${item.title}**\n`
            if (item.snippet) {
              newsReport += `   ${item.snippet}\n`
            }
            if (item.displayed_link) {
              newsReport += `   🔗 ${item.displayed_link}\n`
            }
            newsReport += "\n"
          })

          return newsReport
        }
      }
    } catch (fallbackError) {
      console.error("Fallback news search failed:", fallbackError)
    }

    return `I'm having trouble finding recent ${category} news right now. This could be due to:\n\n• API rate limits\n• Network connectivity\n• Search service issues\n\nPlease try:\n• A different news category\n• Asking again in a moment\n• Checking a specific news website\n\nI can help with other tasks like weather, opening apps, or general questions!`

  } catch (error) {
    console.error("Real-time news error:", error)
    return `I encountered an error while fetching ${category} news. Please try again later or ask me about something else!`
  }
}

export async function getSportsScores(sport: string = "football"): Promise<string> {
  try {
    const apiKey = process.env.SEARCHAPI_KEY

    if (!apiKey) {
      return "Sports scores require SearchAPI configuration. Please add your SEARCHAPI_KEY to enable this feature."
    }

    const currentDate = new Date().toISOString().split('T')[0]
    const searchQueries = [
      `${sport} scores today live results ${currentDate}`,
      `${sport} games today scores ${currentDate}`,
      `latest ${sport} scores results`,
      `${sport} live scores today`
    ]
    
    for (const query of searchQueries) {
      try {
        const searchParams = new URLSearchParams({
          api_key: apiKey,
          engine: "google",
          q: query,
          num: "5"
        })

        const response = await fetch(`https://www.searchapi.io/api/v1/search?${searchParams.toString()}`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        })

        if (response.ok) {
          const data = await response.json()
          const sportsResults = data.sports_results || data.organic_results || []

          if (sportsResults.length > 0) {
            let scoresReport = `**🏆 Latest ${sport.charAt(0).toUpperCase() + sport.slice(1)} Scores:**\n\n`
            
            sportsResults.slice(0, 4).forEach((item: any, index: number) => {
              scoresReport += `${index + 1}. ${item.title || item.snippet || "Score update"}\n`
              if (item.snippet && item.snippet !== item.title) {
                scoresReport += `   ${item.snippet}\n`
              }
              scoresReport += "\n"
            })

            return scoresReport
          }
        }
      } catch (queryError) {
        continue
      }
    }

    return `No recent ${sport} scores found. Please try a different sport or check back later.`

  } catch (error) {
    console.error("Sports scores error:", error)
    return `I'm having trouble getting ${sport} scores right now. Please try again later.`
  }
}

export async function getRealTimeWeather(location: string): Promise<string> {
  // Use existing weather service
  const { getWeatherData } = await import('./weatherService')
  return getWeatherData(location)
}

export async function getMarketData(): Promise<string> {
  try {
    const apiKey = process.env.SEARCHAPI_KEY

    if (!apiKey) {
      return "Market data requires SearchAPI configuration. Please add your SEARCHAPI_KEY to enable this feature."
    }

    const currentDate = new Date().toISOString().split('T')[0]
    const searchQueries = [
      `stock market today dow jones nasdaq s&p 500 ${currentDate}`,
      `stock market news today ${currentDate}`,
      `market updates today stocks`,
      `dow jones nasdaq today performance`
    ]
    
    for (const query of searchQueries) {
      try {
        const searchParams = new URLSearchParams({
          api_key: apiKey,
          engine: "google",
          q: query,
          num: "4"
        })

        const response = await fetch(`https://www.searchapi.io/api/v1/search?${searchParams.toString()}`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        })

        if (response.ok) {
          const data = await response.json()
          const marketResults = data.organic_results || []

          if (marketResults.length > 0) {
            let marketReport = "**📈 Current Market Overview:**\n\n"
            
            marketResults.slice(0, 3).forEach((item: any, index: number) => {
              marketReport += `${index + 1}. ${item.title}\n`
              if (item.snippet) {
                marketReport += `   ${item.snippet}\n`
              }
              marketReport += "\n"
            })

            return marketReport
          }
        }
      } catch (queryError) {
        continue
      }
    }

    return "No recent market data found. Please try again later."

  } catch (error) {
    console.error("Market data error:", error)
    return "I'm having trouble getting market data right now. Please try again later."
  }
}
