"use client"

// Note: These functions work in the browser environment with limitations
// For full system control, a desktop app would be needed

export async function openApplication(appName: string): Promise<string> {
  try {
    const normalizedName = appName.toLowerCase().trim()
    
    // Common web applications and services
    const webApps: { [key: string]: string } = {
      "notepad": "data:text/plain;charset=utf-8,",
      "calculator": "https://www.google.com/search?q=calculator",
      "calendar": "https://calendar.google.com",
      "gmail": "https://gmail.com",
      "youtube": "https://youtube.com",
      "google": "https://google.com",
      "maps": "https://maps.google.com",
      "drive": "https://drive.google.com",
      "docs": "https://docs.google.com",
      "sheets": "https://sheets.google.com",
      "slides": "https://slides.google.com",
      "github": "https://github.com",
      "twitter": "https://twitter.com",
      "facebook": "https://facebook.com",
      "instagram": "https://instagram.com",
      "linkedin": "https://linkedin.com",
      "spotify": "https://open.spotify.com",
      "netflix": "https://netflix.com",
      "amazon": "https://amazon.com",
      "weather": "https://weather.com",
      "news": "https://news.google.com"
    }

    // Check if it's a known web app
    for (const [key, url] of Object.entries(webApps)) {
      if (normalizedName.includes(key)) {
        window.open(url, '_blank')
        return `Opening ${key.charAt(0).toUpperCase() + key.slice(1)} in a new tab.`
      }
    }

    // Try to open as a URL if it looks like one
    if (normalizedName.includes('.com') || normalizedName.includes('.org') || normalizedName.includes('.net')) {
      const url = normalizedName.startsWith('http') ? normalizedName : `https://${normalizedName}`
      window.open(url, '_blank')
      return `Opening ${normalizedName} in a new tab.`
    }

    // For desktop applications, we can only provide guidance
    const desktopApps = [
      "notepad", "calculator", "paint", "cmd", "powershell", "explorer", 
      "chrome", "firefox", "edge", "safari", "vscode", "photoshop", 
      "word", "excel", "powerpoint", "outlook", "teams", "zoom", "discord"
    ]

    const foundApp = desktopApps.find(app => normalizedName.includes(app))
    if (foundApp) {
      return `I can't directly open desktop applications from the browser, but you can open ${foundApp} by:\n• Pressing Windows key and typing "${foundApp}"\n• Using Run dialog (Win+R) and typing the app name\n• Clicking the app icon in your taskbar or desktop`
    }

    return `I couldn't find "${appName}". I can open web applications and websites. Try saying "Open Google" or "Open YouTube" for web apps, or use your system's app launcher for desktop applications.`

  } catch (error) {
    console.error("Error opening application:", error)
    return `I encountered an error trying to open "${appName}". Please try again or open it manually.`
  }
}

export async function typeText(text: string): Promise<string> {
  try {
    // Copy text to clipboard as the best we can do in browser
    await navigator.clipboard.writeText(text)
    
    return `I've copied "${text}" to your clipboard. You can paste it anywhere using Ctrl+V (or Cmd+V on Mac). Note: Direct typing into other applications requires a desktop version of this app.`
    
  } catch (error) {
    console.error("Error with text typing:", error)
    
    // Fallback: create a temporary text area for manual copying
    const textArea = document.createElement('textarea')
    textArea.value = text
    textArea.style.position = 'fixed'
    textArea.style.opacity = '0'
    document.body.appendChild(textArea)
    textArea.select()
    
    try {
      document.execCommand('copy')
      document.body.removeChild(textArea)
      return `I've copied "${text}" to your clipboard. Paste it using Ctrl+V (or Cmd+V on Mac).`
    } catch (fallbackError) {
      document.body.removeChild(textArea)
      return `I couldn't copy the text automatically. Here's what you wanted to type: "${text}". You can copy and paste this manually.`
    }
  }
}

export async function executeSystemCommand(command: string): Promise<string> {
  // Browser limitations - can't execute system commands
  const webCommands: { [key: string]: () => string } = {
    "time": () => `Current time: ${new Date().toLocaleTimeString()}`,
    "date": () => `Current date: ${new Date().toLocaleDateString()}`,
    "reload": () => {
      window.location.reload()
      return "Reloading the page..."
    },
    "back": () => {
      window.history.back()
      return "Going back..."
    },
    "forward": () => {
      window.history.forward()
      return "Going forward..."
    },
    "fullscreen": () => {
      if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen()
        return "Entering fullscreen mode..."
      }
      return "Fullscreen not supported in this browser."
    }
  }

  const normalizedCommand = command.toLowerCase().trim()
  
  for (const [key, action] of Object.entries(webCommands)) {
    if (normalizedCommand.includes(key)) {
      return action()
    }
  }

  return `System command "${command}" cannot be executed from the browser. For full system control, you would need a desktop version of this application.`
}
