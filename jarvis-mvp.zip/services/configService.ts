"use server"

interface ConfigStatus {
  openai: boolean
  elevenlabs: boolean
  searchapi: boolean
}

export async function checkConfiguration(): Promise<ConfigStatus> {
  return {
    openai: !!process.env.OPENAI_API_KEY,
    elevenlabs: !!process.env.ELEVENLABS_API_KEY,
    searchapi: !!process.env.SEARCHAPI_KEY,
  }
}
