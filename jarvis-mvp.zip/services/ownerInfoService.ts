"use server"

interface OwnershipInfo {
  companyName: string
  ownerName: string
  foundedDate?: string
  ownershipDate?: string
  ownerType: string // CEO, Founder, Owner, etc.
  additionalInfo?: string
}

export async function findOwnerInfo(companyName: string): Promise<string> {
  try {
    const apiKey = process.env.SEARCHAPI_KEY

    if (!apiKey) {
      return "Owner information lookup requires SearchAPI configuration. Please add your SEARCHAPI_KEY to enable this feature."
    }

    // Enhanced search query for ownership information
    const searchQueries = [
      `"${companyName}" owner founder CEO`,
      `"${companyName}" founded by established`,
      `"${companyName}" leadership management team`,
      `who owns "${companyName}" company`
    ]

    let bestResult = ""
    
    for (const query of searchQueries) {
      const searchParams = new URLSearchParams({
        api_key: apiKey,
        engine: "google",
        q: query,
        num: "5"
      })

      const response = await fetch(`https://www.searchapi.io/api/v1/search?${searchParams.toString()}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        
        // Extract ownership information from search results
        const ownershipInfo = extractOwnershipInfo(data, companyName)
        if (ownershipInfo) {
          bestResult = formatOwnershipInfo(ownershipInfo)
          break
        }
      }
    }

    return bestResult || `I couldn't find specific ownership information for "${companyName}". This might be due to privacy settings, private ownership, or the company being publicly traded with shareholders.`

  } catch (error) {
    console.error("Owner info service error:", error)
    return `I encountered an error while searching for ownership information about "${companyName}". Please try again later.`
  }
}

function extractOwnershipInfo(searchData: any, companyName: string): OwnershipInfo | null {
  try {
    const results = searchData.organic_results || []
    const knowledgeGraph = searchData.knowledge_graph
    
    let ownerInfo: Partial<OwnershipInfo> = {
      companyName: companyName
    }

    // Check knowledge graph first (most reliable)
    if (knowledgeGraph) {
      if (knowledgeGraph.founder) {
        ownerInfo.ownerName = knowledgeGraph.founder
        ownerInfo.ownerType = "Founder"
      }
      if (knowledgeGraph.founded) {
        ownerInfo.foundedDate = knowledgeGraph.founded
        ownerInfo.ownershipDate = knowledgeGraph.founded
      }
      if (knowledgeGraph.ceo) {
        ownerInfo.ownerName = ownerInfo.ownerName || knowledgeGraph.ceo
        ownerInfo.ownerType = ownerInfo.ownerType || "CEO"
      }
    }

    // Extract from search results
    for (const result of results.slice(0, 3)) {
      const snippet = result.snippet || ""
      const title = result.title || ""
      const text = `${title} ${snippet}`.toLowerCase()

      // Look for ownership patterns
      const ownerPatterns = [
        /founded by ([^,.\n]+)/i,
        /established by ([^,.\n]+)/i,
        /owned by ([^,.\n]+)/i,
        /ceo[:\s]+([^,.\n]+)/i,
        /founder[:\s]+([^,.\n]+)/i,
        /created by ([^,.\n]+)/i
      ]

      const datePatterns = [
        /founded in (\d{4})/i,
        /established in (\d{4})/i,
        /since (\d{4})/i,
        /started in (\d{4})/i
      ]

      for (const pattern of ownerPatterns) {
        const match = text.match(pattern)
        if (match && match[1] && !ownerInfo.ownerName) {
          ownerInfo.ownerName = match[1].trim()
          if (pattern.source.includes('founder')) ownerInfo.ownerType = "Founder"
          else if (pattern.source.includes('ceo')) ownerInfo.ownerType = "CEO"
          else if (pattern.source.includes('owned')) ownerInfo.ownerType = "Owner"
          break
        }
      }

      for (const pattern of datePatterns) {
        const match = text.match(pattern)
        if (match && match[1] && !ownerInfo.foundedDate) {
          ownerInfo.foundedDate = match[1]
          ownerInfo.ownershipDate = match[1]
          break
        }
      }
    }

    return ownerInfo.ownerName ? ownerInfo as OwnershipInfo : null
  } catch (error) {
    console.error("Error extracting ownership info:", error)
    return null
  }
}

function formatOwnershipInfo(info: OwnershipInfo): string {
  let result = `**${info.companyName} Ownership Information:**\n\n`
  
  result += `• **${info.ownerType}:** ${info.ownerName}\n`
  
  if (info.foundedDate) {
    result += `• **Founded:** ${info.foundedDate}\n`
  }
  
  if (info.ownershipDate && info.ownershipDate !== info.foundedDate) {
    result += `• **Ownership Date:** ${info.ownershipDate}\n`
  }
  
  if (info.additionalInfo) {
    result += `• **Additional Info:** ${info.additionalInfo}\n`
  }
  
  result += `\n*Note: This information is based on publicly available data and may not reflect recent changes.*`
  
  return result
}

// Specific searches for different types of organizations
export async function findSchoolOwnership(schoolName: string): Promise<string> {
  const query = `"${schoolName}" principal headmaster director founded established`
  return findOwnerInfo(schoolName)
}

export async function findCompanyOwnership(companyName: string): Promise<string> {
  const query = `"${companyName}" CEO founder owner established`
  return findOwnerInfo(companyName)
}
