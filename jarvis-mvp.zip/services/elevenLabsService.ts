"use server"

// Popular ElevenLabs voice IDs with different characteristics
const AVAILABLE_VOICES = [
  { id: "pNInz6obpgDQGcFmaJgB", name: "Adam" }, // Deep, authoritative
  { id: "EXAVITQu4vr4xnSDxMaL", name: "Bella" }, // Warm, friendly female
  { id: "ErXwobaYiN019PkySvjV", name: "Antoni" }, // Smooth, professional
  { id: "VR6AewLTigWG4xSOukaG", name: "Arnold" }, // Strong, confident
  { id: "MF3mGyEYCl7XYWbV9V6O", name: "Elli" }, // Young, energetic female
  { id: "TxGEqnHWrfWFTfGW9XjX", name: "Josh" }, // Casual, conversational
  { id: "rSwuIhIUY1AI4YFvdHBq", name: "Liam" }, // British accent, sophisticated
  { id: "pqHfZKP75CvOlQylNhV4", name: "Bill" }, // Older, wise-sounding - JARVIS default
  { id: "N2lVS1w4EtoT3dr4eOWO", name: "Callum" }, // Young, clear
  { id: "IKne3meq5aSn9XLyUdCD", name: "Charlie" }, // Neutral, professional
]

async function getBillVoice() {
  return AVAILABLE_VOICES.find((voice) => voice.name === "Bill") || AVAILABLE_VOICES[7]
}

async function getRandomVoice() {
  const randomIndex = Math.floor(Math.random() * AVAILABLE_VOICES.length)
  return AVAILABLE_VOICES[randomIndex]
}

export async function generateSpeech(text: string, useRandomVoice = false): Promise<Blob> {
  try {
    const apiKey = process.env.ELEVENLABS_API_KEY

    if (!apiKey) {
      console.warn("ElevenLabs API key not configured - falling back to browser TTS")
      // Return empty blob when API key is missing
      return new Blob()
    }

    // Use Bill voice by default, or random if specified
    const selectedVoice = useRandomVoice ? await getRandomVoice() : await getBillVoice()
    console.log(`Attempting ElevenLabs voice: ${selectedVoice.name} (${selectedVoice.id})`)

    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${selectedVoice.id}`, {
      method: "POST",
      headers: {
        Accept: "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": apiKey,
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
          stability: 0.6,
          similarity_boost: 0.7,
          style: 0.2,
          use_speaker_boost: true,
        },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error")
      console.warn(`ElevenLabs API error: ${response.status} - ${errorText}`)
      console.warn("Falling back to browser text-to-speech")

      // Return empty blob to trigger fallback
      return new Blob()
    }

    console.log(`ElevenLabs speech generated successfully with ${selectedVoice.name} voice`)
    return await response.blob()
  } catch (error) {
    console.warn("ElevenLabs service error:", error)
    console.warn("Falling back to browser text-to-speech")
    // Return empty blob as fallback
    return new Blob()
  }
}

// Optional: Function to get a specific voice by name
export async function generateSpeechWithVoice(text: string, voiceName: string): Promise<Blob> {
  try {
    const apiKey = process.env.ELEVENLABS_API_KEY

    if (!apiKey) {
      console.warn("ElevenLabs API key not configured - falling back to browser TTS")
      return new Blob()
    }

    const selectedVoice =
      AVAILABLE_VOICES.find((voice) => voice.name.toLowerCase() === voiceName.toLowerCase()) || (await getBillVoice())

    console.log(`Using requested voice: ${selectedVoice.name} (${selectedVoice.id})`)

    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${selectedVoice.id}`, {
      method: "POST",
      headers: {
        Accept: "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": apiKey,
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
          stability: 0.6,
          similarity_boost: 0.7,
          style: 0.2,
          use_speaker_boost: true,
        },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error")
      console.warn(`ElevenLabs API error: ${response.status} - ${errorText}`)
      return new Blob()
    }

    return await response.blob()
  } catch (error) {
    console.warn("ElevenLabs service error:", error)
    return new Blob()
  }
}

// Export available voices for UI selection
export async function getAvailableVoices() {
  return AVAILABLE_VOICES
}
