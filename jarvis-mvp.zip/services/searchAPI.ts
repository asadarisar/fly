"use server"

interface SearchOptions {
  query: string
  kgmid?: string // Knowledge Graph identifier
  location?: string
  language?: string
  country?: string
  num?: number // Number of results
}

export async function searchQuery(query: string, options?: Partial<SearchOptions>): Promise<string | null> {
  try {
    const apiKey = process.env.SEARCHAPI_KEY

    if (!apiKey) {
      return "Search functionality is not available - SearchAPI key not configured. Please add your SEARCHAPI_KEY to enable web search capabilities."
    }

    // Build search parameters with api_key as query parameter
    const searchParams = new URLSearchParams({
      api_key: apiKey,
      engine: "google",
      q: query,
    })

    // Add optional parameters
    if (options?.kgmid) {
      searchParams.append("kgmid", options.kgmid)
    }
    if (options?.location) {
      searchParams.append("location", options.location)
    }
    if (options?.language) {
      searchParams.append("hl", options.language)
    }
    if (options?.country) {
      searchParams.append("gl", options.country)
    }
    if (options?.num) {
      searchParams.append("num", options.num.toString())
    }

    console.log(`Searching with SearchAPI: ${query}`)

    const response = await fetch(`https://www.searchapi.io/api/v1/search?${searchParams.toString()}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(`SearchAPI error: ${response.status} - ${errorData.message || "Unknown error"}`)
    }

    const data = await response.json()

    // Extract search results with enhanced formatting
    const organicResults = data.organic_results || []
    const knowledgeGraph = data.knowledge_graph
    const answerBox = data.answer_box

    if (organicResults.length === 0 && !knowledgeGraph && !answerBox) {
      return "No search results found for your query."
    }

    let formattedResults = ""

    // Add answer box if available (direct answers)
    if (answerBox) {
      formattedResults += `Direct Answer: ${answerBox.answer || answerBox.snippet}\n\n`
    }

    // Add knowledge graph info if available
    if (knowledgeGraph) {
      const title = knowledgeGraph.title || ""
      const description = knowledgeGraph.description || ""
      const type = knowledgeGraph.type || ""

      formattedResults += `Knowledge Graph: ${title}`
      if (type) formattedResults += ` (${type})`
      if (description) formattedResults += ` - ${description}`
      formattedResults += "\n\n"
    }

    // Format the top search results
    const topResults = organicResults
      .slice(0, 3)
      .map((result: any, index: number) => {
        const title = result.title || "No title"
        const snippet = result.snippet || "No description available"
        const link = result.link || ""
        const displayLink = result.displayed_link || new URL(link).hostname

        return `${index + 1}. ${title}\n   ${snippet}\n   Source: ${displayLink}`
      })
      .join("\n\n")

    formattedResults += topResults

    console.log("SearchAPI results retrieved successfully")
    return formattedResults
  } catch (error) {
    console.error("SearchAPI service error:", error)

    if (error instanceof Error) {
      if (error.message.includes("401")) {
        return "Search API authentication failed. Please check your SEARCHAPI_KEY."
      }
      if (error.message.includes("403")) {
        return "Search API access forbidden. Please verify your API key permissions."
      }
      if (error.message.includes("429")) {
        return "Search API rate limit exceeded. Please try again later."
      }
    }

    return "I encountered an error while searching. Please try again later."
  }
}

// Enhanced search with specific parameters
export async function searchWithKnowledgeGraph(query: string, kgmid: string): Promise<string | null> {
  return searchQuery(query, { kgmid })
}

// Location-specific search
export async function searchByLocation(query: string, location: string): Promise<string | null> {
  return searchQuery(query, { location })
}

// Advanced search with multiple parameters
export async function advancedSearch(options: SearchOptions): Promise<string | null> {
  return searchQuery(options.query, options)
}

// Search with specific number of results
export async function searchWithLimit(query: string, numResults: number): Promise<string | null> {
  return searchQuery(query, { num: numResults })
}

// Multi-language search
export async function searchInLanguage(query: string, language: string, country?: string): Promise<string | null> {
  return searchQuery(query, { language, country })
}
