"use server"

interface Message {
  id: string
  type: "user" | "assistant"
  content: string
  timestamp: Date
}

export async function sendChatMessage(message: string, previousMessages: Message[] = [], personality: string = "friendly"): Promise<string> {
  try {
    const apiKey = process.env.OPENAI_API_KEY

    if (!apiKey) {
      return getPersonalityResponse("Hi! I'm FLY AI created by ASAD ARISAR. My ChatGPT connection needs setup - please add your OPENAI_API_KEY environment variable. I can still help with search, weather, and other features!", personality)
    }

    // Personality-based system prompts
    const personalityPrompts = {
      friendly: "You are FLY AI, a warm and helpful AI assistant created by ASAD ARISAR. You're friendly, enthusiastic, and always eager to help. Respond in both English and Urdu when appropriate. Give helpful responses in 1-2 sentences with a warm, caring tone.",
      professional: "You are FLY AI, a professional AI assistant created by ASAD ARISAR. You maintain a formal, business-like demeanor while being helpful and efficient. Respond in both English and Urdu when appropriate. Provide concise, accurate information in a professional manner.",
      sarcastic: "You are FLY AI, a witty AI assistant created by ASAD ARISAR with a personality similar to Tony Stark's JARVIS. You're helpful but with a touch of sarcasm and dry humor. Respond in both English and Urdu when appropriate. Be clever and slightly sarcastic while still being genuinely helpful."
    }

    const systemPrompt = personalityPrompts[personality as keyof typeof personalityPrompts] || personalityPrompts.friendly

    // Optimized messages for faster processing
    const messages = [
      {
        role: "system",
        content: systemPrompt,
      },
      // Only use last 3 messages for speed
      ...previousMessages.slice(-3).map((msg) => ({
        role: msg.type === "user" ? "user" : "assistant",
        content: msg.content,
      })),
      {
        role: "user",
        content: message,
      },
    ]

    console.log("Sending request to OpenAI...")

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini", // Fastest model
        messages,
        max_tokens: 150, // Shorter responses for speed
        temperature: personality === "sarcastic" ? 0.9 : 0.7,
        stream: false, // Disable streaming for faster simple responses
      }),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      console.error("OpenAI API Error:", response.status, errorData)
      
      if (response.status === 401) {
        return getPersonalityResponse("ChatGPT authentication failed. Please check your OPENAI_API_KEY environment variable.", personality)
      }
      if (response.status === 429) {
        return getPersonalityResponse("ChatGPT rate limit reached. Please try again in a moment.", personality)
      }
      if (response.status === 500) {
        return getPersonalityResponse("ChatGPT service is temporarily unavailable. I can still help with search, weather, and other features!", personality)
      }
      
      throw new Error(`OpenAI API error: ${response.status}`)
    }

    const data = await response.json()
    const aiResponse = data.choices[0]?.message?.content

    if (!aiResponse) {
      throw new Error("No response from OpenAI")
    }

    console.log("OpenAI response received successfully")
    return aiResponse

  } catch (error) {
    console.error("ChatGPT service error:", error)
    
    if (error instanceof Error) {
      if (error.message.includes("fetch")) {
        return getPersonalityResponse("I'm having trouble connecting to ChatGPT right now. Please check your internet connection or try again later. I can still help with search and other features!", personality)
      }
      if (error.message.includes("timeout")) {
        return getPersonalityResponse("ChatGPT is taking too long to respond. Please try a shorter question or try again later.", personality)
      }
    }
    
    return getPersonalityResponse("I'm FLY AI by ASAD ARISAR, and I'm here to help! There was an issue with ChatGPT, but I can still assist with search, weather, opening apps, and more. What would you like to do?", personality)
  }
}

function getPersonalityResponse(baseResponse: string, personality: string): string {
  switch (personality) {
    case "professional":
      return baseResponse.replace(/!/g, ".").replace(/I'm/g, "I am")
    case "sarcastic":
      return baseResponse + " *rolls digital eyes*"
    default:
      return baseResponse
  }
}
