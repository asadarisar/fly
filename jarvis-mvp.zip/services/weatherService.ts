"use server"

interface WeatherData {
  location: string
  temperature: number
  description: string
  humidity: number
  windSpeed: number
  feelsLike: number
}

export async function getWeatherData(location = "auto"): Promise<string> {
  try {
    // You can replace this with your weather API key
    const apiKey = process.env.WEATHER_API_KEY || process.env.OPENWEATHER_API_KEY

    if (!apiKey) {
      return `Weather service needs configuration. Please add your WEATHER_API_KEY or OPENWEATHER_API_KEY to environment variables. I can help with other questions in the meantime!`
    }

    // Example using OpenWeatherMap API (you can replace with your preferred weather API)
    const weatherUrl =
      location === "auto"
        ? `https://api.openweathermap.org/data/2.5/weather?q=London&appid=${apiKey}&units=metric`
        : `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&appid=${apiKey}&units=metric`

    const response = await fetch(weatherUrl)

    if (!response.ok) {
      if (response.status === 401) {
        return "Weather API authentication failed. Please check your weather API key."
      }
      if (response.status === 404) {
        return `I couldn't find weather information for "${location}". Please check the location name and try again.`
      }
      throw new Error(`Weather API error: ${response.status}`)
    }

    const data = await response.json()

    const weather: WeatherData = {
      location: data.name + (data.sys?.country ? `, ${data.sys.country}` : ""),
      temperature: Math.round(data.main.temp),
      description: data.weather[0]?.description || "Unknown",
      humidity: data.main.humidity,
      windSpeed: data.wind?.speed || 0,
      feelsLike: Math.round(data.main.feels_like),
    }

    return `Weather in ${weather.location}: ${weather.temperature}°C, ${weather.description}. Feels like ${weather.feelsLike}°C. Humidity: ${weather.humidity}%, Wind: ${weather.windSpeed} m/s.`
  } catch (error) {
    console.error("Weather service error:", error)
    return `I'm having trouble getting weather information right now. Please try again later or ask me something else!`
  }
}

// Alternative weather service for different APIs
export async function getWeatherWithCustomAPI(location: string, apiEndpoint: string, apiKey: string): Promise<string> {
  try {
    const response = await fetch(`${apiEndpoint}?location=${encodeURIComponent(location)}&key=${apiKey}`)

    if (!response.ok) {
      throw new Error(`Custom weather API error: ${response.status}`)
    }

    const data = await response.json()

    // You'll need to adapt this based on your weather API's response format
    return `Weather data retrieved successfully! Please customize the response format in weatherService.ts based on your API structure.`
  } catch (error) {
    console.error("Custom weather API error:", error)
    return "I'm having trouble with the weather service. Please check your API configuration."
  }
}
